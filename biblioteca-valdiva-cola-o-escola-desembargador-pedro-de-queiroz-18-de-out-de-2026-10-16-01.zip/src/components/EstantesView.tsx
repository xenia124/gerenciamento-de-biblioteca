import React, { useState } from 'react';
import { 
  FolderArchive, 
  BookMarked, 
  Layers, 
  Search, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  BookOpen, 
  Filter, 
  Eye 
} from 'lucide-react';
import { Livro } from '../types/library';
import { ESTANTES_PADRAO } from '../data/initialData';

interface EstantesViewProps {
  livros: Livro[];
  onSelectBook: (livro: Livro) => void;
  onOpenNovoLivro: (estanteLetraDefault?: string) => void;
}

export const EstantesView: React.FC<EstantesViewProps> = ({
  livros,
  onSelectBook,
  onOpenNovoLivro,
}) => {
  const [estanteSelecionada, setEstanteSelecionada] = useState<string>('A-1');
  const [termoFiltro, setTermoFiltro] = useState<string>('');

  // Group books by shelf letter
  const livrosPorEstante = ESTANTES_PADRAO.map(est => {
    const livrosDaEstante = livros.filter(l => l.estanteLetra === est.letra);
    const disponiveis = livrosDaEstante.filter(l => l.disponivel === 'Sim').length;
    const emprestados = livrosDaEstante.filter(l => l.disponivel === 'Não').length;
    return {
      ...est,
      total: livrosDaEstante.length,
      disponiveis,
      emprestados,
      livros: livrosDaEstante,
    };
  });

  const estanteAtual = livrosPorEstante.find(e => e.letra === estanteSelecionada) || livrosPorEstante[0];

  const livrosFiltrados = estanteAtual.livros.filter(l => 
    l.titulo.toLowerCase().includes(termoFiltro.toLowerCase()) ||
    l.autor.toLowerCase().includes(termoFiltro.toLowerCase()) ||
    l.genero.toLowerCase().includes(termoFiltro.toLowerCase()) ||
    l.tombo.toLowerCase().includes(termoFiltro.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Overview Cards for A-Z Shelves */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Organização Física das Estantes (A-1, A-2, A-3 e Setores)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Mapeamento do acervo da Biblioteca Valdiva Colaço · EMEF Desembargador Pedro de Queiroz (Projeto: Xênia Cardoso - 2026)
            </p>
          </div>
          <button
            onClick={() => onOpenNovoLivro(estanteSelecionada)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 transition-all cursor-pointer whitespace-nowrap self-start shadow-sm"
          >
            <BookOpen className="w-4 h-4" />
            <span>Adicionar Livro na Estante {estanteSelecionada}</span>
          </button>
        </div>

        {/* Shelves Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {livrosPorEstante.map((est) => {
            const isSelected = est.letra === estanteSelecionada;
            return (
              <button
                key={est.letra}
                onClick={() => setEstanteSelecionada(est.letra)}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                  isSelected
                    ? 'bg-blue-900 text-white border-blue-950 shadow-md ring-2 ring-orange-500'
                    : 'bg-white text-slate-800 border-slate-200 hover:border-blue-400 hover:shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`w-9 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                    isSelected ? 'bg-orange-500 text-white' : 'bg-blue-50 text-blue-900'
                  }`}>
                    {est.letra}
                  </span>
                  <span className={`text-[11px] font-mono font-semibold ${isSelected ? 'text-blue-200' : 'text-slate-500'}`}>
                    {est.total} {est.total === 1 ? 'obra' : 'obras'}
                  </span>
                </div>

                <div className={`text-xs font-bold truncate ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                  Estante {est.letra}
                </div>
                <div className={`text-[10px] truncate mt-0.5 ${isSelected ? 'text-blue-200' : 'text-slate-500'}`}>
                  {est.nome.split('·')[1] || est.nome}
                </div>

                <div className="mt-3 pt-2 border-t border-slate-100/20 flex items-center justify-between text-[10px]">
                  <span className={isSelected ? 'text-emerald-300' : 'text-emerald-700 font-medium'}>
                    {est.disponiveis} disp.
                  </span>
                  <span className={isSelected ? 'text-amber-300' : 'text-amber-700 font-medium'}>
                    {est.emprestados} emp.
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Shelf Detail View */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-orange-600 text-white font-bold text-xs">
                {estanteAtual.letra}
              </span>
              <h3 className="text-base font-bold text-slate-900">
                {estanteAtual.nome}
              </h3>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
              <span>Classificação oficial da ficha escolar</span>
              <span>·</span>
              <span>Total de volumes: <strong>{estanteAtual.total}</strong></span>
              <span>·</span>
              <span className="text-emerald-600 font-medium">{estanteAtual.disponiveis} disponíveis</span>
              <span>·</span>
              <span className="text-orange-600 font-medium">{estanteAtual.emprestados} emprestados</span>
            </div>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={termoFiltro}
              onChange={(e) => setTermoFiltro(e.target.value)}
              placeholder={`Filtrar na Estante ${estanteAtual.letra}...`}
              className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50"
            />
          </div>
        </div>

        {/* Shelf Books Grid */}
        {livrosFiltrados.length === 0 ? (
          <div className="py-12 text-center text-slate-500">
            <BookMarked className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">Nenhum livro encontrado nesta estante.</p>
            <p className="text-xs text-slate-400 mt-1">Adicione uma obra nova ou ajuste o termo do filtro.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {livrosFiltrados.map((livro) => (
              <div
                key={livro.id}
                onClick={() => onSelectBook(livro)}
                className="p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition-all bg-white cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200 font-bold">
                      Tombo: {livro.tombo}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      livro.disponivel === 'Sim' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {livro.disponivel === 'Sim' ? 'Disponível' : 'Emprestado'}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-900 line-clamp-1">
                    {livro.titulo}
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {livro.autor} · {livro.ano}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Gênero: <strong>{livro.genero}</strong> {livro.secao && `· Seção ${livro.secao}`}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-blue-900 font-semibold group-hover:text-orange-600">
                  <span>Ver ficha catalográfica</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
