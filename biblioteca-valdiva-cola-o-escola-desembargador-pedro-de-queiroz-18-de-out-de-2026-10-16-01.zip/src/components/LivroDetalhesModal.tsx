import React from 'react';
import { 
  X, 
  BookOpen, 
  User, 
  Calendar, 
  Layers, 
  Barcode, 
  FileText, 
  RotateCcw, 
  ArrowLeftRight, 
  Check, 
  Clock, 
  Pencil,
  Bookmark
} from 'lucide-react';
import { Livro, Emprestimo } from '../types/library';
import { VoltarButton, ConfirmarButton, CorrigirButton, CancelarButton } from './common/ActionButtons';

interface LivroDetalhesModalProps {
  livro: Livro | null;
  emprestimoAtivo?: Emprestimo | null;
  onClose: () => void;
  onEditar: (livro: Livro) => void;
  onIniciarEmprestimo: (livro: Livro) => void;
  onDevolver: (emprestimoId: string) => void;
}

export const LivroDetalhesModal: React.FC<LivroDetalhesModalProps> = ({
  livro,
  emprestimoAtivo,
  onClose,
  onEditar,
  onIniciarEmprestimo,
  onDevolver,
}) => {
  if (!livro) return null;

  const isDisponivel = livro.disponivel === 'Sim';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full flex flex-col shadow-2xl overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between border-b border-blue-950">
          <div className="flex items-center gap-3">
            <BookOpen className="w-5 h-5 text-orange-400" />
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">Ficha Catalográfica Oficial</h3>
              <p className="text-xs text-blue-200">Biblioteca Valdiva Colaço · EMEF Desembargador Pedro de Queiroz (2026)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          <div className="flex flex-col sm:flex-row gap-5 items-start">
            
            {/* Book Spine Emblem (No AI Images) */}
            <div className="w-28 h-40 rounded-xl bg-gradient-to-b from-blue-900 via-blue-950 to-slate-900 shadow-md border border-blue-900 shrink-0 flex flex-col items-center justify-between text-center p-3 text-white">
              <Bookmark className="w-6 h-6 text-orange-400" />
              <div className="font-bold text-[11px] leading-tight px-1">
                {livro.titulo}
              </div>
              <div className="font-mono text-[10px] text-blue-200 bg-white/10 px-2 py-0.5 rounded">
                Tombo: {livro.tombo}
              </div>
            </div>

            {/* Core Info */}
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200">
                  Nº de Tombo: {livro.tombo}
                </span>
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                  isDisponivel ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {isDisponivel ? 'Disponível no Acervo' : 'Emprestado'}
                </span>
              </div>

              <h2 className="text-lg font-bold text-slate-900 leading-tight">
                {livro.titulo}
              </h2>
              <div className="text-sm font-semibold text-slate-700">
                {livro.autor}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-slate-600">
                <div>Ano: <strong className="text-slate-800 font-mono">{livro.ano}</strong></div>
                <div>Gênero: <strong className="text-slate-800">{livro.genero}</strong></div>
                <div>Editora: <strong className="text-slate-800">{livro.editora || 'Escolar'}</strong></div>
                <div>Páginas: <strong className="text-slate-800 font-mono">{livro.paginas || '-'}</strong></div>
                <div>Estante: <strong className="text-slate-800 font-mono">{livro.estanteLetra}</strong></div>
                <div>Cadastrado em: <strong className="text-slate-800 font-mono">{livro.dataCadastro}</strong></div>
              </div>
            </div>
          </div>

          {/* Physical Location in Shelves */}
          <div className="p-3.5 bg-blue-50/80 rounded-xl border border-blue-200 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold text-blue-900 uppercase tracking-wider">Localização Física no Acervo Escolar</div>
              <div className="text-xs font-bold text-blue-950 mt-0.5">{livro.estante}</div>
              <div className="text-[11px] text-blue-800">Seção Cadastrada: <strong>{livro.secao || livro.estanteLetra}</strong></div>
            </div>
            <span className="px-3 py-1.5 rounded-xl bg-blue-900 text-white font-bold text-sm shadow-sm font-mono">
              {livro.estanteLetra}
            </span>
          </div>

          {/* Loan status banner */}
          {!isDisponivel && emprestimoAtivo && (
            <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                <Clock className="w-4 h-4 text-amber-700" />
                <span>Empréstimo em Curso</span>
              </div>
              <p className="text-xs text-amber-950">
                Em posse de: <strong>{emprestimoAtivo.usuarioNome}</strong> ({emprestimoAtivo.usuarioSerieTurma || emprestimoAtivo.usuarioCategoria})
              </p>
              <div className="flex items-center gap-4 text-[11px] text-amber-800 pt-1">
                <span>Retirada: {emprestimoAtivo.dataEmprestimo}</span>
                <span>·</span>
                <span>Devolução prevista: <strong>{emprestimoAtivo.dataPrevista}</strong></span>
              </div>
            </div>
          )}

          {/* Synopsis */}
          {livro.sinopse && (
            <div className="space-y-1">
              <div className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">Observações / Sinopse da Obra</div>
              <p className="p-3 bg-slate-50 rounded-xl text-slate-600 leading-relaxed border border-slate-200">
                {livro.sinopse}
              </p>
            </div>
          )}
        </div>

        {/* Modal Action Controls: [confirmar, voltar, cancelar, corrigir] */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <VoltarButton onClick={onClose} label="Voltar" />

          <div className="flex items-center gap-2">
            <CorrigirButton
              onClick={() => {
                onClose();
                onEditar(livro);
              }}
              label="Corrigir / Editar"
            />

            {isDisponivel ? (
              <ConfirmarButton
                onClick={() => {
                  onClose();
                  onIniciarEmprestimo(livro);
                }}
                label="Realizar Empréstimo"
              />
            ) : emprestimoAtivo ? (
              <button
                onClick={() => {
                  onClose();
                  onDevolver(emprestimoAtivo.id);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-bold text-white bg-slate-900 hover:bg-orange-600 transition-colors shadow cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-orange-400" />
                <span>Registrar Devolução</span>
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};
