import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Clock, 
  MessageSquare, 
  Phone, 
  Mail, 
  Check, 
  Copy, 
  ExternalLink, 
  RotateCcw, 
  Filter,
  UserCheck,
  Calendar,
  Send,
  Sparkles
} from 'lucide-react';
import { Emprestimo, Usuario, Livro } from '../types/library';
import { ConfirmarButton, VoltarButton, CancelarButton, CorrigirButton } from './common/ActionButtons';

interface NotificacoesAtrasoViewProps {
  emprestimos: Emprestimo[];
  usuarios: Usuario[];
  livros: Livro[];
  onRegistrarDevolucao: (emprestimoId: string) => void;
  onMarcarNotificado: (emprestimoId: string) => void;
}

export const NotificacoesAtrasoView: React.FC<NotificacoesAtrasoViewProps> = ({
  emprestimos,
  usuarios,
  livros,
  onRegistrarDevolucao,
  onMarcarNotificado,
}) => {
  const [selectedLoan, setSelectedLoan] = useState<Emprestimo | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filtroCategoria, setFiltroCategoria] = useState<string>('todos');

  // Filter overdue loans
  const hoje = new Date().toISOString().split('T')[0];
  
  const emprestimosAtrasados = emprestimos
    .filter(e => e.status !== 'devolvido' && (e.status === 'atrasado' || e.dataPrevista < hoje))
    .map(e => {
      // Calculate delay days
      const dataPrevistaDate = new Date(e.dataPrevista);
      const hojeDate = new Date(hoje);
      const diffTime = Math.max(0, hojeDate.getTime() - dataPrevistaDate.getTime());
      const diasCalculados = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return {
        ...e,
        diasAtraso: diasCalculados || e.diasAtraso || 1,
      };
    })
    .sort((a, b) => (b.diasAtraso || 0) - (a.diasAtraso || 0));

  const filteredList = emprestimosAtrasados.filter(e => {
    if (filtroCategoria === 'alunos') {
      return e.usuarioCategoria === 'aluno' || e.usuarioCategoria === 'aluna';
    }
    if (filtroCategoria === 'professores') {
      return e.usuarioCategoria === 'professor' || e.usuarioCategoria === 'professora';
    }
    if (filtroCategoria === 'servidores') {
      return e.usuarioCategoria === 'servidor' || e.usuarioCategoria === 'servidora';
    }
    return true;
  });

  const gerarTextoNotificacao = (e: Emprestimo): string => {
    return `Olá, ${e.usuarioNome}! Aqui é a equipe da Biblioteca Valdiva Colaço da EMEF Desembargador Pedro de Queiroz (Projeto: Xênia Cardoso - Ano: 2026).\n\nConstatamos em nosso sistema escolar que a devolução do livro "${e.livroTitulo}" (Nº de Tombo: ${e.livroTombo}) estava prevista para ${e.dataPrevista} (atualmente com ${e.diasAtraso} dias de atraso).\n\nPedimos gentilmente que compareça à biblioteca para a devolução ou renovação da obra, permitindo que outros estudantes tenham acesso ao acervo.\n\nAgradecemos sua cooperação! 📚\nEquipe de Mediação · Biblioteca Valdiva Colaço`;
  };

  const handleCopyMessage = (e: Emprestimo) => {
    const text = gerarTextoNotificacao(e);
    navigator.clipboard.writeText(text);
    setCopiedId(e.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleOpenWhatsApp = (e: Emprestimo) => {
    const text = encodeURIComponent(gerarTextoNotificacao(e));
    const cleanPhone = e.usuarioTelefone.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
    window.open(`https://wa.me/${phoneWithCountry}?text=${text}`, '_blank');
    onMarcarNotificado(e.id);
  };

  const handleOpenEmail = (e: Emprestimo) => {
    const subject = encodeURIComponent(`Biblioteca Valdiva Colaço - Devolução de Livro Pendente: ${e.livroTitulo}`);
    const body = encodeURIComponent(gerarTextoNotificacao(e));
    window.location.href = `mailto:${e.usuarioEmail}?subject=${subject}&body=${body}`;
    onMarcarNotificado(e.id);
  };

  return (
    <div className="space-y-6">
      {/* Alert Header */}
      <div className="bg-gradient-to-r from-red-950 via-orange-950 to-slate-900 border border-orange-800/40 rounded-2xl p-6 text-white shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-orange-600/30 border border-orange-500/50 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6 text-orange-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold tracking-tight">
                  Painel de Notificações de Devoluções em Atraso
                </h2>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-red-600 text-white">
                  {emprestimosAtrasados.length} pendente(s)
                </span>
              </div>
              <p className="text-xs text-orange-200/80 mt-1 max-w-2xl">
                Sistema automatizado para monitorar prazos de entrega expirados, gerar avisos cordiais para WhatsApp e E-mail de alunos e servidores da EMEF Desembargador Pedro de Queiroz (Projeto: Xênia Cardoso - 2026).
              </p>
            </div>
          </div>

          {/* Quick Segment Filter */}
          <div className="flex items-center gap-1.5 p-1 bg-black/30 rounded-xl border border-white/10 shrink-0">
            <button
              onClick={() => setFiltroCategoria('todos')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filtroCategoria === 'todos' ? 'bg-orange-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'
              }`}
            >
              Todos ({emprestimosAtrasados.length})
            </button>
            <button
              onClick={() => setFiltroCategoria('alunos')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filtroCategoria === 'alunos' ? 'bg-orange-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'
              }`}
            >
              Alunos
            </button>
            <button
              onClick={() => setFiltroCategoria('professores')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                filtroCategoria === 'professores' ? 'bg-orange-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'
              }`}
            >
              Professores
            </button>
          </div>
        </div>
      </div>

      {/* Overdue Loans List */}
      {filteredList.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
          <UserCheck className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">Parabéns! Nenhuma pendência em atraso nesta categoria.</h3>
          <p className="text-xs text-slate-500 mt-1">Todos os empréstimos ativos estão dentro do prazo estipulado pela biblioteca.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredList.map((loan) => {
            const isSelected = selectedLoan?.id === loan.id;
            return (
              <div
                key={loan.id}
                className={`bg-white rounded-xl border transition-all p-5 shadow-sm flex flex-col justify-between ${
                  isSelected ? 'border-orange-500 ring-2 ring-orange-200' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div>
                  {/* Top Bar of Card */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{loan.usuarioNome}</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200 uppercase">
                          {loan.usuarioCategoria}
                        </span>
                      </div>
                      {loan.usuarioSerieTurma && (
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {loan.usuarioSerieTurma}
                        </div>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-md bg-red-100 text-red-800 border border-red-200">
                        <Clock className="w-3.5 h-3.5 text-red-600" />
                        <span>{loan.diasAtraso} dias de atraso</span>
                      </span>
                    </div>
                  </div>

                  {/* Book Info */}
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80 mb-3 space-y-1">
                    <div className="text-xs font-bold text-slate-900 line-clamp-1">
                      {loan.livroTitulo}
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-slate-500">
                      <span>Tombo: <strong>{loan.livroTombo}</strong></span>
                      <span>·</span>
                      <span>Empréstimo: {loan.dataEmprestimo}</span>
                      <span>·</span>
                      <span className="text-red-700 font-medium">Prazo: {loan.dataPrevista}</span>
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="flex items-center gap-4 text-xs text-slate-600 mb-4">
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{loan.usuarioTelefone}</span>
                    </div>
                    <div className="flex items-center gap-1.5 truncate">
                      <Mail className="w-3.5 h-3.5 text-blue-600" />
                      <span className="truncate">{loan.usuarioEmail}</span>
                    </div>
                  </div>
                </div>

                {/* Notification Action Controls */}
                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenWhatsApp(loan)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 cursor-pointer transition-colors"
                      title="Enviar lembrete pelo WhatsApp"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                      <span>WhatsApp</span>
                    </button>

                    <button
                      onClick={() => handleOpenEmail(loan)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200 cursor-pointer transition-colors"
                      title="Enviar e-mail escolar"
                    >
                      <Mail className="w-3.5 h-3.5 text-blue-600" />
                      <span>E-mail</span>
                    </button>

                    <button
                      onClick={() => handleCopyMessage(loan)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer transition-colors"
                      title="Copiar texto do aviso"
                    >
                      {copiedId === loan.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700">Copiado!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-500" />
                          <span>Copiar</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Register Return */}
                  <button
                    onClick={() => onRegistrarDevolucao(loan.id)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 cursor-pointer transition-colors shadow-sm ml-auto"
                  >
                    <Check className="w-3.5 h-3.5 text-orange-400" />
                    <span>Devolver Livro</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
