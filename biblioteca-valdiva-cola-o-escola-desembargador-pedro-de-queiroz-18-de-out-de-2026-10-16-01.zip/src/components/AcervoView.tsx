import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  ArrowUpDown, 
  BookOpen, 
  Filter, 
  Check, 
  Clock, 
  Pencil, 
  Trash2, 
  Barcode, 
  Sparkles,
  Layers,
  Eye,
  Bookmark
} from 'lucide-react';
import { Livro } from '../types/library';
import { ESTANTES_PADRAO, GENEROS_LIVROS } from '../data/initialData';
import { ConfirmarButton, VoltarButton, CancelarButton, CorrigirButton } from './common/ActionButtons';

interface AcervoViewProps {
  livros: Livro[];
  onOpenNovoLivro: () => void;
  onOpenEditarLivro: (livro: Livro) => void;
  onDeleteLivro: (livroId: string) => void;
  onSelectLivroDetalhes: (livro: Livro) => void;
}

type CriterioOrdenacao = 'tombo_asc' | 'titulo_asc' | 'titulo_desc' | 'autor_asc' | 'ano_desc' | 'ano_asc' | 'estante_asc';

export const AcervoView: React.FC<AcervoViewProps> = ({
  livros,
  onOpenNovoLivro,
  onOpenEditarLivro,
  onDeleteLivro,
  onSelectLivroDetalhes,
}) => {
  const [termoBusca, setTermoBusca] = useState('');
  const [filtroGenero, setFiltroGenero] = useState<string>('todos');
  const [filtroEstante, setFiltroEstante] = useState<string>('todas');
  const [filtroDisponibilidade, setFiltroDisponibilidade] = useState<string>('todos');
  const [ordenacao, setOrdenacao] = useState<CriterioOrdenacao>('tombo_asc');

  // Filter books
  const livrosFiltrados = livros.filter((livro) => {
    const matchTermo = 
      livro.titulo.toLowerCase().includes(termoBusca.toLowerCase()) ||
      livro.autor.toLowerCase().includes(termoBusca.toLowerCase()) ||
      livro.tombo.toLowerCase().includes(termoBusca.toLowerCase()) ||
      (livro.isbn && livro.isbn.includes(termoBusca));

    if (!matchTermo) return false;

    if (filtroGenero !== 'todos' && livro.genero !== filtroGenero) {
      return false;
    }

    if (filtroEstante !== 'todas' && livro.estanteLetra !== filtroEstante) {
      return false;
    }

    if (filtroDisponibilidade === 'disponiveis' && livro.disponivel !== 'Sim') {
      return false;
    }

    if (filtroDisponibilidade === 'emprestados' && livro.disponivel !== 'Não') {
      return false;
    }

    return true;
  });

  // Sorting
  const livrosOrdenados = [...livrosFiltrados].sort((a, b) => {
    if (ordenacao === 'tombo_asc') {
      return a.tombo.localeCompare(b.tombo, undefined, { numeric: true });
    }
    if (ordenacao === 'titulo_asc') {
      return a.titulo.localeCompare(b.titulo);
    }
    if (ordenacao === 'titulo_desc') {
      return b.titulo.localeCompare(a.titulo);
    }
    if (ordenacao === 'autor_asc') {
      return a.autor.localeCompare(b.autor);
    }
    if (ordenacao === 'ano_desc') {
      return b.ano - a.ano;
    }
    if (ordenacao === 'ano_asc') {
      return a.ano - b.ano;
    }
    if (ordenacao === 'estante_asc') {
      return a.estanteLetra.localeCompare(b.estanteLetra);
    }
    return 0;
  });

  const handleDelete = (livro: Livro) => {
    if (confirm(`Tem certeza que deseja excluir "${livro.titulo}" (Tombo: ${livro.tombo}) do acervo escolar?`)) {
      onDeleteLivro(livro.id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner and Quick CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Catálogo Oficial de Livros da Biblioteca Valdiva Colaço
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            EMEF Desembargador Pedro de Queiroz · Projeto: Xênia Cardoso (Ano: 2026) · Estantes A-1, A-2 e A-3
          </p>
        </div>

        <button
          onClick={onOpenNovoLivro}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 shadow-sm transition-all cursor-pointer whitespace-nowrap self-start"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Novo Livro</span>
        </button>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Main Search Input */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={termoBusca}
              onChange={(e) => setTermoBusca(e.target.value)}
              placeholder="Buscar por Tombo (ex: 0001), título, autor ou gênero..."
              className="w-full text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50"
            />
          </div>

          {/* Shelf Filter */}
          <div>
            <select
              value={filtroEstante}
              onChange={(e) => setFiltroEstante(e.target.value)}
              className="w-full text-xs px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 font-medium"
            >
              <option value="todas">Todas as Estantes</option>
              {ESTANTES_PADRAO.map(est => (
                <option key={est.letra} value={est.letra}>
                  {est.nome}
                </option>
              ))}
            </select>
          </div>

          {/* Genre Filter */}
          <div>
            <select
              value={filtroGenero}
              onChange={(e) => setFiltroGenero(e.target.value)}
              className="w-full text-xs px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 font-medium"
            >
              <option value="todos">Todos os Gêneros</option>
              {GENEROS_LIVROS.map(g => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Secondary controls strip */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Disponibilidade:</span>
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg">
              <button
                onClick={() => setFiltroDisponibilidade('todos')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                  filtroDisponibilidade === 'todos' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                Todos ({livros.length})
              </button>
              <button
                onClick={() => setFiltroDisponibilidade('disponiveis')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                  filtroDisponibilidade === 'disponiveis' ? 'bg-white text-emerald-800 shadow-sm' : 'text-slate-600'
                }`}
              >
                Disponíveis
              </button>
              <button
                onClick={() => setFiltroDisponibilidade('emprestados')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                  filtroDisponibilidade === 'emprestados' ? 'bg-white text-amber-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                Emprestados
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-500 font-medium">Ordenar:</span>
              <select
                value={ordenacao}
                onChange={(e) => setOrdenacao(e.target.value as CriterioOrdenacao)}
                className="text-xs px-2.5 py-1 rounded-md border border-slate-200 bg-white font-medium"
              >
                <option value="tombo_asc">Nº de Tombo (Oficial)</option>
                <option value="titulo_asc">Título (A-Z)</option>
                <option value="titulo_desc">Título (Z-A)</option>
                <option value="autor_asc">Autor (A-Z)</option>
                <option value="ano_desc">Ano (Mais recente)</option>
                <option value="ano_asc">Ano (Mais antigo)</option>
                <option value="estante_asc">Estante (A-1, A-2, A-3...)</option>
              </select>
            </div>

            <div className="text-slate-500 text-[11px] font-mono">
              Mostrando <strong>{livrosOrdenados.length}</strong> de {livros.length}
            </div>
          </div>
        </div>
      </div>

      {/* Books Content */}
      {livrosOrdenados.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
          <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">Nenhum livro localizado</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Não encontramos livros que correspondam aos filtros selecionados. Tente limpar os filtros ou cadastrar uma nova obra.
          </p>
          <button
            onClick={() => {
              setTermoBusca('');
              setFiltroGenero('todos');
              setFiltroEstante('todas');
              setFiltroDisponibilidade('todos');
            }}
            className="mt-4 px-4 py-2 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
          >
            Limpar todos os filtros
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {livrosOrdenados.map((livro) => {
            const isDisponivel = livro.disponivel === 'Sim';

            return (
              <div
                key={livro.id}
                className="bg-white rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group"
              >
                {/* Book Card Header & Clean Emblem (No AI Images) */}
                <div className="p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    
                    {/* Clean SVG Book Spine / Emblem */}
                    <div className="w-12 h-16 rounded-lg bg-gradient-to-b from-blue-900 to-indigo-950 text-white flex flex-col items-center justify-between p-1.5 shrink-0 shadow-sm border border-blue-900">
                      <Bookmark className="w-3.5 h-3.5 text-orange-400" />
                      <span className="font-mono text-[9px] font-bold text-blue-200 tracking-wider">
                        {livro.tombo}
                      </span>
                    </div>

                    {/* Metadata text */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200">
                          Nº {livro.tombo}
                        </span>

                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isDisponivel ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isDisponivel ? 'Disponível' : 'Emprestado'}
                        </span>
                      </div>

                      <h3
                        onClick={() => onSelectLivroDetalhes(livro)}
                        className="text-sm font-bold text-slate-900 group-hover:text-blue-900 transition-colors line-clamp-2 cursor-pointer leading-tight"
                        title={livro.titulo}
                      >
                        {livro.titulo}
                      </h3>

                      <p className="text-xs text-slate-600 mt-1 line-clamp-1 font-medium">
                        {livro.autor}
                      </p>

                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1.5">
                        <span>{livro.ano}</span>
                        <span>·</span>
                        <span className="truncate">{livro.genero}</span>
                      </div>
                    </div>
                  </div>

                  {/* Shelf Location Box */}
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 text-[11px] flex items-center justify-between text-slate-600">
                    <span className="font-semibold text-blue-900">{livro.estante}</span>
                    <span className="text-[10px] font-mono text-slate-500 font-semibold">{livro.secao}</span>
                  </div>
                </div>

                {/* Actions bottom strip */}
                <div className="p-3 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => onSelectLivroDetalhes(livro)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-blue-900 hover:text-orange-600 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Ficha da Obra</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onOpenEditarLivro(livro)}
                      className="p-1.5 rounded-md text-slate-600 hover:text-blue-900 hover:bg-white transition-colors cursor-pointer"
                      title="Editar registro"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(livro)}
                      className="p-1.5 rounded-md text-slate-400 hover:text-red-700 hover:bg-white transition-colors cursor-pointer"
                      title="Excluir livro do acervo"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
