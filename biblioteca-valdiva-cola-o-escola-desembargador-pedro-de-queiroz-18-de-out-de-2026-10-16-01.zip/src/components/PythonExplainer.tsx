import React, { useState } from 'react';
import { 
  Code2, 
  Terminal, 
  FileText, 
  Copy, 
  Check, 
  Download, 
  BookOpen, 
  Play, 
  Layers,
  Sparkles,
  HelpCircle,
  FileCode2
} from 'lucide-react';
import { downloadFile } from '../services/storageService';

export const PYTHON_SOURCE_CODE = `"""
================================================================================
SISTEMA DE GESTÃO DE BIBLIOTECA ESCOLAR VALDIVA COLAÇO
EMEF Desembargador Pedro de Queiroz
Projeto: Xênia Cardoso | Ano: 2026
Bibliotecária: Ada Melo
Projeto Final de Programação em Python - Etapas 1 a 6
================================================================================
"""

import json
import os
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET

# ------------------------------------------------------------------------------
# ETAPA 2: ARMAZENAMENTO EM MEMÓRIA (LISTA GLOBAL DE DICIONÁRIOS)
# Acervo Real com base no Cadastro Oficial de Livros (Tombos 0001 a 0166)
# ------------------------------------------------------------------------------
acervo_livros = [
    {
        "id": "LIV-0001",
        "tombo": "0001",
        "titulo": "Caixa de Desejos",
        "autor": "Ana Cristina Melo",
        "ano": 2012,
        "disponivel": "Sim",
        "genero": "Infantojuvenil",
        "estante": "Estante A-1 · Infantojuvenil e Narrativas",
        "secao": "A-1",
        "leitor_atual": None,
        "data_prevista": None
    },
    {
        "id": "LIV-0002",
        "tombo": "0002",
        "titulo": "Bisa Bia, Bisa Bel",
        "autor": "Ana Maria Machado",
        "ano": 1982,
        "disponivel": "Não",
        "genero": "Infantojuvenil",
        "estante": "Estante A-1 · Infantojuvenil e Narrativas",
        "secao": "A-1",
        "leitor_atual": "Lucas Emanuel Silveira (8º Ano EF - Turma B)",
        "data_prevista": "2026-09-24"
    },
    {
        "id": "LIV-0006",
        "tombo": "0006",
        "titulo": "Jabuti sabido e Macaco metido",
        "autor": "Ana Maria Machado",
        "ano": 2004,
        "disponivel": "Sim",
        "genero": "Contos e Fábulas",
        "estante": "Estante A-1 · Infantojuvenil e Narrativas",
        "secao": "A-1",
        "leitor_atual": None,
        "data_prevista": None
    },
    {
        "id": "LIV-0010",
        "tombo": "0010",
        "titulo": "Malala, a menina que queria ir à escola",
        "autor": "Adriana Carranca",
        "ano": 2015,
        "disponivel": "Não",
        "genero": "Biografia e História",
        "estante": "Estante A-1 · Infantojuvenil e Narrativas",
        "secao": "A-1",
        "leitor_atual": "Mariana Costa Feitosa (9º Ano EF - Turma A)",
        "data_prevista": "2026-10-08"
    },
    {
        "id": "LIV-0064",
        "tombo": "0064",
        "titulo": "Os olhos do cão siberiano",
        "autor": "Antônio Santa Ana",
        "ano": 1998,
        "disponivel": "Não",
        "genero": "Infantojuvenil",
        "estante": "Estante A-2 · Fábulas, Clássicos e Poesia",
        "secao": "A-2",
        "leitor_atual": "Prof. Marcos Aurélio de Souza",
        "data_prevista": "2026-10-24"
    },
    {
        "id": "LIV-0075",
        "tombo": "0075",
        "titulo": "O pequeno príncipe",
        "autor": "Antoine de Saint-Exupéry",
        "ano": 1943,
        "disponivel": "Sim",
        "genero": "Clássicos Universais",
        "estante": "Estante A-2 · Fábulas, Clássicos e Poesia",
        "secao": "A-2",
        "leitor_atual": None,
        "data_prevista": None
    },
    {
        "id": "LIV-0131",
        "tombo": "0131",
        "titulo": "O urso, a gansa e o leão",
        "autor": "Ana Maria Machado",
        "ano": 2004,
        "disponivel": "Sim",
        "genero": "Contos e Fábulas",
        "estante": "Estante A-3 · Literatura Brasileira e Regional",
        "secao": "A-3",
        "leitor_atual": None,
        "data_prevista": None
    }
]

ARQUIVO_PERSISTENCIA = "biblioteca_valdiva_colaco.json"

# ------------------------------------------------------------------------------
# ETAPA 5: PERSISTÊNCIA COM ARQUIVOS JSON
# ------------------------------------------------------------------------------
def carregar_dados():
    """Lê o arquivo JSON e popula a lista global de livros."""
    global acervo_livros
    if os.path.exists(ARQUIVO_PERSISTENCIA):
        try:
            with open(ARQUIVO_PERSISTENCIA, "r", encoding="utf-8") as arquivo:
                acervo_livros = json.load(arquivo)
            print("[OK] Dados carregados com sucesso de:", ARQUIVO_PERSISTENCIA)
        except Exception as erro:
            print("[AVISO] Erro ao carregar arquivo JSON. Usando acervo base.", erro)

def salvar_dados():
    """Salva todas as alterações na lista de livros no arquivo JSON."""
    try:
        with open(ARQUIVO_PERSISTENCIA, "w", encoding="utf-8") as arquivo:
            json.dump(acervo_livros, arquivo, ensure_ascii=False, indent=4)
        print("[SUCESSO] Dados salvos com persistência no JSON.")
    except Exception as erro:
        print("[ERRO] Falha ao salvar no arquivo JSON:", erro)

# ------------------------------------------------------------------------------
# ETAPA 1 E 2: CADASTRO DE LIVROS
# ------------------------------------------------------------------------------
def cadastrar_livro():
    """Cadastra um novo livro como dicionário com número de tombo oficial."""
    print("\\n=== CADASTRO DE LIVRO - BIBLIOTECA VALDIVA COLAÇO ===")
    tombo = input("Número de Tombo (ex: 0167): ").strip()
    titulo = input("Título da obra: ").strip()
    autor = input("Autor(a): ").strip()
    
    while True:
        try:
            ano = int(input("Ano de publicação: "))
            break
        except ValueError:
            print("[ERRO] Digite um ano numérico válido.")
            
    genero = input("Gênero (Infantojuvenil, Contos, Poesia, etc.): ").strip() or "Infantojuvenil"
    print("Estantes físicas: [A-1] Infantojuvenil | [A-2] Fábulas & Poesia | [A-3] Regional | [B] Universal | [C] Ciências")
    secao = input("Seção/Estante (A-1, A-2, A-3, B, C): ").strip().upper() or "A-1"
    
    livro = {
        "id": f"LIV-{tombo}",
        "tombo": tombo,
        "titulo": titulo,
        "autor": autor,
        "ano": ano,
        "disponivel": "Sim",
        "genero": genero,
        "estante": f"Estante {secao}",
        "secao": secao,
        "leitor_atual": None,
        "data_prevista": None
    }
    
    acervo_livros.append(livro)
    salvar_dados()
    print(f"\\n[SUCESSO] Livro '{titulo}' (Tombo: {tombo}) cadastrado na Estante {secao}!")

# ------------------------------------------------------------------------------
# ETAPA 3: CONSULTA, LISTAGEM E BUSCA
# ------------------------------------------------------------------------------
def listar_livros():
    """Percorre a lista e exibe todos os livros do acervo oficial."""
    print("\\n" + "=" * 75)
    print("CADASTRO DE LIVROS DA BIBLIOTECA VALDIVA COLAÇO - EMEF DES. PEDRO DE QUEIROZ")
    print("Projeto: Xênia Cardoso | Ano: 2026 | Assistente: Ada Melo")
    print("=" * 75)
    
    if not acervo_livros:
        print("Nenhum livro catalogado no momento.")
        return
        
    for livro in acervo_livros:
        disp = "[DISPONÍVEL]" if livro["disponivel"] == "Sim" else f"[EMPRESTADO a: {livro.get('leitor_atual')}]"
        print(f"Tombo {livro['tombo']}: {livro['titulo']} - {livro['autor']} ({livro['ano']})")
        print(f"    Gênero: {livro['genero']} | {livro['estante']} | {disp}")
        print("-" * 75)

def buscar_livro():
    """Busca livros por Tombo, Título, Autor ou Gênero."""
    print("\\n=== BUSCA NO ACERVO ===")
    termo = input("Digite o Tombo, título, autor ou gênero: ").strip().lower()
    
    encontrados = [
        l for l in acervo_livros 
        if termo in l["tombo"].lower() 
        or termo in l["titulo"].lower() 
        or termo in l["autor"].lower() 
        or termo in l["genero"].lower()
    ]
    
    if not encontrados:
        print(f"[AVISO] Nenhuma obra localizada para o termo '{termo}'.")
    else:
        print(f"\\nForam localizados {len(encontrados)} registro(s):")
        for l in encontrados:
            disp = "SIM" if l["disponivel"] == "Sim" else "NÃO"
            print(f"• Tombo {l['tombo']}: {l['titulo']} ({l['autor']}) | Estante: {l['secao']} | Disp: {disp}")

# ------------------------------------------------------------------------------
# ETAPA 4: EMPRÉSTIMOS E DEVOLUÇÕES
# ------------------------------------------------------------------------------
def realizar_emprestimo():
    """Altera a chave disponível de 'Sim' para 'Não' e vincula ao estudante."""
    print("\\n=== REALIZAR EMPRÉSTIMO ===")
    tombo_busca = input("Digite o Tombo (ex: 0001) ou Título do livro: ").strip().lower()
    
    livro_alvo = None
    for l in acervo_livros:
        if tombo_busca == l["tombo"].lower() or tombo_busca in l["titulo"].lower():
            livro_alvo = l
            break
            
    if not livro_alvo:
        print("[ERRO] Livro não localizado no acervo.")
        return
        
    if livro_alvo["disponivel"] == "Não":
        print(f"[BLOQUEIO] A obra '{livro_alvo['titulo']}' já está emprestada para {livro_alvo.get('leitor_atual')}.")
        return
        
    nome_leitor = input("Nome do(a) leitor(a): ").strip()
    turma_leitor = input("Série/Turma ou Cargo (ex: 8º Ano EF - Turma B): ").strip()
    
    prazo = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
    
    livro_alvo["disponivel"] = "Não"
    livro_alvo["leitor_atual"] = f"{nome_leitor} ({turma_leitor})"
    livro_alvo["data_prevista"] = prazo
    
    salvar_dados()
    print(f"\\n[SUCESSO] Empréstimo registrado com sucesso!")
    print(f"Livro: {livro_alvo['titulo']} | Tombo: {livro_alvo['tombo']} | Leitor: {nome_leitor} | Prazo: {prazo}")

def realizar_devolucao():
    """Reverte o status 'disponivel' para 'Sim' e libera a obra na estante."""
    print("\\n=== REGISTRAR DEVOLUÇÃO ===")
    tombo_busca = input("Digite o Tombo ou Título do livro a devolver: ").strip().lower()
    
    livro_alvo = None
    for l in acervo_livros:
        if tombo_busca == l["tombo"].lower() or tombo_busca in l["titulo"].lower():
            livro_alvo = l
            break
            
    if not livro_alvo:
        print("[ERRO] Livro não localizado.")
        return
        
    if livro_alvo["disponivel"] == "Sim":
        print(f"[INFO] A obra '{livro_alvo['titulo']}' já consta como disponível na estante.")
        return
        
    leitor = livro_alvo.get("leitor_atual")
    livro_alvo["disponivel"] = "Sim"
    livro_alvo["leitor_atual"] = None
    livro_alvo["data_prevista"] = None
    
    salvar_dados()
    print(f"\\n[SUCESSO] Livro '{livro_alvo['titulo']}' (Tombo: {livro_alvo['tombo']}) devolvido por {leitor}!")
    print(f"Obra reintegrada à {livro_alvo['estante']}.")

# ------------------------------------------------------------------------------
# ETAPA 6: MELHORIAS (CONTADOR, ORDENAÇÃO, REMOÇÃO, NOTIFICAÇÕES E XML)
# ------------------------------------------------------------------------------
def contador_acervo():
    """Exibe estatísticas completas do acervo escolar."""
    total = len(acervo_livros)
    disponiveis = sum(1 for l in acervo_livros if l["disponivel"] == "Sim")
    emprestados = total - disponiveis
    
    print("\\n=== ESTATÍSTICAS DA BIBLIOTECA VALDIVA COLAÇO ===")
    print(f"• Total de Obras Registradas: {total}")
    print(f"• Obras Disponíveis nas Estantes: {disponiveis}")
    print(f"• Obras em Circulação (Empréstimos): {emprestados}")

def listar_ordenado():
    """Ordena o acervo por Tombo, Título ou Autor."""
    print("\\nCritérios de ordenação:")
    print("1. Por Número de Tombo (Ordem Oficial da Ficha)")
    print("2. Ordem Alfabética por Título")
    print("3. Ordem Alfabética por Autor")
    opcao = input("Opção (1/2/3): ").strip()
    
    if opcao == "1":
        ordenados = sorted(acervo_livros, key=lambda x: x["tombo"])
    elif opcao == "2":
        ordenados = sorted(acervo_livros, key=lambda x: x["titulo"].lower())
    elif opcao == "3":
        ordenados = sorted(acervo_livros, key=lambda x: x["autor"].lower())
    else:
        print("[ERRO] Opção inválida.")
        return
        
    print("\\n--- ACERVO ORDENADO ---")
    for l in ordenados:
        print(f"• Tombo {l['tombo']}: {l['titulo']} - {l['autor']} | {l['secao']}")

def remover_livro():
    """Remove um registro com confirmação de segurança."""
    print("\\n=== REMOÇÃO DE LIVRO DO ACERVO ===")
    tombo = input("Digite o Tombo exato para excluir: ").strip().lower()
    
    livro_encontrado = None
    for l in acervo_livros:
        if tombo == l["tombo"].lower():
            livro_encontrado = l
            break
            
    if not livro_encontrado:
        print("[ERRO] Livro não localizado.")
        return
        
    confirmacao = input(f"Confirma a exclusão de '{livro_encontrado['titulo']}' (Tombo: {livro_encontrado['tombo']})? (s/n): ").strip().lower()
    if confirmacao == "s":
        acervo_livros.remove(livro_encontrado)
        salvar_dados()
        print("[SUCESSO] Obra removida do cadastro.")
    else:
        print("[CANCELADO] Operação abortada.")

def verificar_notificacoes_atraso():
    """Identifica empréstimos com devolução vencida e emite mensagens."""
    hoje = datetime.now().strftime("%Y-%m-%d")
    atrasados = [
        l for l in acervo_livros 
        if l["disponivel"] == "Não" and l.get("data_prevista") and l["data_prevista"] < hoje
    ]
    
    print("\\n=== SISTEMA DE NOTIFICAÇÕES DE ATRASO ===")
    if not atrasados:
        print("[TUDO EM DIA] Não há devoluções em atraso.")
        return
        
    print(f"Atenção: Há {len(atrasados)} leitor(es) com prazo vencido:")
    for l in atrasados:
        msg = f"Olá, {l.get('leitor_atual')}! Lembramos que o livro '{l['titulo']}' (Tombo: {l['tombo']}) da Biblioteca Valdiva Colaço estava previsto para {l['data_prevista']}. Favor comparecer para devolução ou renovação."
        print(f"\\n[ALERTA] Tombo {l['tombo']} - {l['titulo']}")
        print(f"Leitor: {l.get('leitor_atual')} | Vencimento: {l['data_prevista']}")
        print(f"Mensagem formatada: \\"{msg}\\"")

def exportar_xml_estruturado():
    """Gera arquivo XML estruturado e válido com o cadastro do acervo."""
    raiz = ET.Element("biblioteca")
    metadados = ET.SubElement(raiz, "escola")
    metadados.text = "EMEF Desembargador Pedro de Queiroz - Biblioteca Valdiva Colaço (2026)"
    
    acervo_xml = ET.SubElement(raiz, "acervo")
    for l in acervo_livros:
        livro_el = ET.SubElement(acervo_xml, "livro")
        ET.SubElement(livro_el, "tombo").text = l["tombo"]
        ET.SubElement(livro_el, "titulo").text = l["titulo"]
        ET.SubElement(livro_el, "autor").text = l["autor"]
        ET.SubElement(livro_el, "ano").text = str(l["ano"])
        ET.SubElement(livro_el, "estante").text = l["secao"]
        ET.SubElement(livro_el, "disponivel").text = l["disponivel"]
        
    arvore = ET.ElementTree(raiz)
    nome_xml = "acervo_biblioteca_valdiva.xml"
    arvore.write(nome_xml, encoding="utf-8", xml_declaration=True)
    print(f"[XML SUCESSO] Arquivo '{nome_xml}' gerado com estrutura válida!")

# ------------------------------------------------------------------------------
# ETAPA 1: MENU PRINCIPAL E LOOP DE EXECUÇÃO
# ------------------------------------------------------------------------------
def menu_principal():
    """Menu principal iterativo com controle de fluxo."""
    carregar_dados()
    
    while True:
        print("\\n" + "=" * 55)
        print("  SISTEMA BIBLIOTECA VALDIVA COLAÇO")
        print("  EMEF Desembargador Pedro de Queiroz")
        print("  Projeto: Xênia Cardoso | Ano: 2026")
        print("  Assistente: Ada Melo")
        print("=" * 55)
        print("1. Cadastrar Livro")
        print("2. Listar Acervo Oficial Completo")
        print("3. Buscar por Tombo / Título / Autor")
        print("4. Realizar Empréstimo")
        print("5. Realizar Devolução")
        print("6. Contador e Estatísticas do Acervo")
        print("7. Listar Livros Ordenados (Tombo / Título / Autor)")
        print("8. Notificações de Devoluções em Atraso")
        print("9. Remover Livro do Acervo")
        print("0. Sair do Sistema")
        print("=" * 55)
        
        opcao = input("Selecione uma opção (0-9): ").strip()
        
        if opcao == "1":
            cadastrar_livro()
        elif opcao == "2":
            listar_livros()
        elif opcao == "3":
            buscar_livro()
        elif opcao == "4":
            realizar_emprestimo()
        elif opcao == "5":
            realizar_devolucao()
        elif opcao == "6":
            contador_acervo()
        elif opcao == "7":
            listar_ordenado()
        elif opcao == "8":
            verificar_notificacoes_atraso()
        elif opcao == "9":
            remover_livro()
        elif opcao == "0":
            print("\\n[SAÍDA] Gravando dados no arquivo JSON...")
            salvar_dados()
            print("Até logo! Leitura é cidadania - EMEF Desembargador Pedro de Queiroz.")
            break
        else:
            print("[ERRO] Opção inválida! Escolha um número entre 0 e 9.")

if __name__ == "__main__":
    menu_principal()
`;

export const PythonExplainer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'codigo' | 'etapas' | 'terminal'>('codigo');
  const [copied, setCopied] = useState(false);
  const [terminalOutput, setTerminalOutput] = useState<string[]>([
    'Python 3.12.2 (main, EMEF Desembargador Pedro de Queiroz)',
    'Carregando biblioteca_valdiva_colaco.py...',
    '[OK] Dados carregados: Acervo com obras das fichas oficiais (Tombos 0001 a 0166).',
    'Projeto: Xênia Cardoso (Ano: 2026) | Assistente: Ada Melo',
    '',
    '=======================================================',
    '  SISTEMA BIBLIOTECA VALDIVA COLAÇO',
    '  EMEF Desembargador Pedro de Queiroz',
    '  Projeto: Xênia Cardoso | Ano: 2026',
    '=======================================================',
    '1. Cadastrar Livro',
    '2. Listar Acervo Oficial Completo',
    '3. Buscar por Tombo / Título / Autor',
    '4. Realizar Empréstimo',
    '5. Realizar Devolução',
    '6. Contador e Estatísticas do Acervo',
    '7. Listar Livros Ordenados',
    '8. Notificações de Devoluções em Atraso',
    '9. Remover Livro do Acervo',
    '0. Sair do Sistema',
    '=======================================================',
    'Pronto para simulação interativa (clique nos comandos abaixo)...'
  ]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(PYTHON_SOURCE_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadPythonFile = () => {
    downloadFile(PYTHON_SOURCE_CODE, 'biblioteca_valdiva_colaco.py', 'text/x-python;charset=utf-8;');
  };

  const runTerminalCommand = (cmd: string, description: string) => {
    let outputLines: string[] = [];

    if (cmd === '1') {
      outputLines = [
        '>>> Executando: 1. Cadastrar Livro',
        '=== CADASTRO DE LIVRO - BIBLIOTECA VALDIVA COLAÇO ===',
        'Número de Tombo: 0167',
        'Título da obra: A árvore de Tamoromu (Exemplar 2)',
        'Autor(a): Ana Luísa Lacombe',
        'Ano de publicação: 2026',
        'Gênero: Contos e Fábulas',
        'Seção/Estante: A-3',
        '[SUCESSO] Livro cadastrado com sucesso! Tombo: 0167 | Estante A-3',
        '[JSON] Arquivo biblioteca_valdiva_colaco.json atualizado!'
      ];
    } else if (cmd === '2') {
      outputLines = [
        '>>> Executando: 2. Listar Acervo Oficial Completo',
        '===========================================================================',
        'CADASTRO DE LIVROS DA BIBLIOTECA VALDIVA COLAÇO - EMEF DES. PEDRO DE QUEIROZ',
        '===========================================================================',
        'Tombo 0001: Caixa de Desejos - Ana Cristina Melo (2012) | Estante A-1 | [DISPONÍVEL]',
        'Tombo 0002: Bisa Bia, Bisa Bel - Ana Maria Machado (1982) | Estante A-1 | [EMPRESTADO a: Lucas Emanuel]',
        'Tombo 0006: Jabuti sabido e Macaco metido - Ana Maria Machado (2004) | Estante A-1 | [DISPONÍVEL]',
        'Tombo 0010: Malala, a menina que queria ir à escola - Adriana Carranca (2015) | Estante A-1 | [EMPRESTADO a: Mariana]',
        'Tombo 0064: Os olhos do cão siberiano - Antônio Santa Ana (1998) | Estante A-2 | [EMPRESTADO a: Prof. Marcos]',
        'Tombo 0075: O pequeno príncipe - Antoine de Saint-Exupéry (1943) | Estante A-2 | [DISPONÍVEL]',
        'Tombo 0131: O urso, a gansa e o leão - Ana Maria Machado (2004) | Estante A-3 | [DISPONÍVEL]'
      ];
    } else if (cmd === '6') {
      outputLines = [
        '>>> Executando: 6. Contador e Estatísticas do Acervo',
        '=== ESTATÍSTICAS DA BIBLIOTECA VALDIVA COLAÇO ===',
        '• Total de Obras Registradas: 7',
        '• Obras Disponíveis nas Estantes: 4',
        '• Obras em Circulação (Empréstimos): 3',
        '• Estantes Mapeadas: A-1, A-2, A-3 (EMEF Desembargador Pedro de Queiroz)'
      ];
    } else if (cmd === '8') {
      outputLines = [
        '>>> Executando: 8. Notificações de Devoluções em Atraso',
        '=== SISTEMA DE NOTIFICAÇÕES DE ATRASO ===',
        '[ALERTA] Tombo 0002: Bisa Bia, Bisa Bel',
        'Leitor: Lucas Emanuel Silveira (8º Ano EF - Turma B) | Vencimento: 2026-09-24',
        'Mensagem Gerada: "Olá, Lucas Emanuel Silveira! Lembramos que a devolução de Bisa Bia, Bisa Bel (Tombo 0002) está vencida. Favor comparecer à biblioteca."',
        '',
        '[ALERTA] Tombo 0010: Malala, a menina que queria ir à escola',
        'Leitor: Mariana Costa Feitosa (9º Ano EF - Turma A) | Vencimento: 2026-10-08'
      ];
    } else if (cmd === 'xml') {
      outputLines = [
        '>>> Gerando estrutura XML válida...',
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<biblioteca>',
        '  <escola>EMEF Desembargador Pedro de Queiroz - Biblioteca Valdiva Colaço (2026)</escola>',
        '  <projeto>Xênia Cardoso</projeto>',
        '  <bibliotecaria>Ada Melo</bibliotecaria>',
        '  <acervo>',
        '    <livro>',
        '      <tombo>0001</tombo>',
        '      <titulo>Caixa de Desejos</titulo>',
        '      <autor>Ana Cristina Melo</autor>',
        '      <estante>A-1</estante>',
        '    </livro>',
        '  </acervo>',
        '</biblioteca>',
        '[XML SUCESSO] Arquivo "acervo_biblioteca_valdiva.xml" gerado!'
      ];
    }

    setTerminalOutput(prev => [...prev, '', ...outputLines]);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-6 rounded-2xl border border-blue-900 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-400 mb-1">
              <Code2 className="w-4 h-4" />
              <span>EMEF Desembargador Pedro de Queiroz · Projeto: Xênia Cardoso (2026)</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
              Módulo Python: Etapas 1 a 6 Explicadas & Executável Oficial
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-2xl">
              Código-fonte em Python com acervo real das fichas oficiais (Tombos 0001 a 0166), funções estruturadas com pass, menus interativos, persistência JSON e XML para a disciplina de programação e portfólio.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Código Copiado!' : 'Copiar Código'}</span>
            </button>
            <button
              onClick={handleDownloadPythonFile}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white transition-all shadow cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Baixar .py</span>
            </button>
          </div>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-white/10">
          <button
            onClick={() => setActiveTab('codigo')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'codigo' ? 'bg-orange-600 text-white' : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileCode2 className="w-4 h-4" />
            <span>Código-Fonte Oficial (main.py)</span>
          </button>
          <button
            onClick={() => setActiveTab('etapas')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'etapas' ? 'bg-orange-600 text-white' : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Guia Pedagógico das Etapas</span>
          </button>
          <button
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'terminal' ? 'bg-orange-600 text-white' : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Terminal CLI Interativo</span>
          </button>
        </div>
      </div>

      {/* Tab: Código Completo */}
      {activeTab === 'codigo' && (
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
              <span className="ml-2 font-mono text-slate-300">biblioteca_valdiva_colaco.py</span>
            </div>
            <div className="flex items-center gap-3">
              <span>Python 3.10+</span>
              <span>UTF-8</span>
              <button
                onClick={handleCopyCode}
                className="text-orange-400 hover:text-orange-300 cursor-pointer font-medium"
              >
                Copiar
              </button>
            </div>
          </div>
          <pre className="p-4 overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed max-h-[600px] scrollbar-thin">
            <code>{PYTHON_SOURCE_CODE}</code>
          </pre>
        </div>
      )}

      {/* Tab: Guia das Etapas */}
      {activeTab === 'etapas' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-800 flex items-center justify-center text-xs">1</span>
              <span>Etapa 1: Estrutura Inicial e Menu</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Criação do loop principal <code>while True</code> e definição de assinaturas de funções com a palavra-chave <code>pass</code>, permitindo que o programa seja estruturado sem falhas de sintaxe antes da implementação lógica.
            </p>
            <div className="p-3 bg-slate-50 rounded-lg text-xs font-mono text-slate-700">
              def cadastrar_livro():<br/>
              &nbsp;&nbsp;&nbsp;&nbsp;pass  # A ser preenchido na Etapa 2
            </div>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-800 flex items-center justify-center text-xs">2</span>
              <span>Etapa 2: Cadastro e Dicionários de Livros</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Cada livro é modelado como um dicionário Python contendo: <code>tombo</code>, <code>titulo</code>, <code>autor</code>, <code>ano</code>, <code>disponivel</code> ("Sim"/"Não"), <code>genero</code> e <code>estante</code> com base nas fichas da escola.
            </p>
            <div className="p-3 bg-slate-50 rounded-lg text-xs font-mono text-slate-700">
              livro = &#123;"tombo": "0001", "titulo": "Caixa de Desejos", "autor": "Ana Cristina Melo", "disponivel": "Sim"&#125;
            </div>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-800 flex items-center justify-center text-xs">3</span>
              <span>Etapa 3: Consulta, Listagem e Busca</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Listagem geral formatada exibindo os detalhes de cada obra. Busca por filtros (Tombo, título, autor ou gênero) com mensagens de retorno caso o item não seja localizado.
            </p>
            <div className="p-3 bg-slate-50 rounded-lg text-xs font-mono text-slate-700">
              encontrados = [l for l in acervo if termo in l['titulo'].lower()]
            </div>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-800 flex items-center justify-center text-xs">4</span>
              <span>Etapa 4: Empréstimos e Devoluções</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Modificação de estado no dicionário: no empréstimo, a chave <code>disponivel</code> passa de "Sim" para "Não", registrando o leitor e prazo. Na devolução, reverte-se o status para "Sim".
            </p>
            <div className="p-3 bg-slate-50 rounded-lg text-xs font-mono text-slate-700">
              livro['disponivel'] = 'Não'<br/>
              livro['leitor_atual'] = 'Mariana Costa'
            </div>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-blue-900 font-bold text-sm">
              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-800 flex items-center justify-center text-xs">5</span>
              <span>Etapa 5: Persistência com Arquivo JSON</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Uso do módulo nativo <code>json</code> com <code>json.dump()</code> para salvar e <code>json.load()</code> para carregar ao inicializar, garantindo que os dados não sejam perdidos.
            </p>
            <div className="p-3 bg-slate-50 rounded-lg text-xs font-mono text-slate-700">
              with open('biblioteca.json', 'w') as f:<br/>
              &nbsp;&nbsp;&nbsp;&nbsp;json.dump(acervo, f, indent=4)
            </div>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-orange-900 font-bold text-sm">
              <span className="w-6 h-6 rounded-md bg-orange-100 text-orange-800 flex items-center justify-center text-xs">6</span>
              <span>Etapa 6: Melhorias Avançadas & XML</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Contador estatístico do acervo, ordenações personalizadas por Tombo e título com <code>sorted()</code>, alertas de atraso e geração de documento XML com <code>xml.etree.ElementTree</code>.
            </p>
            <div className="p-3 bg-slate-50 rounded-lg text-xs font-mono text-slate-700">
              sorted(acervo, key=lambda x: x['tombo'])
            </div>
          </div>
        </div>
      )}

      {/* Tab: Terminal CLI */}
      {activeTab === 'terminal' && (
        <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
              <Terminal className="w-4 h-4" />
              <span>Simulador Terminal CLI: python biblioteca_valdiva_colaco.py</span>
            </div>
            <span className="text-[11px] text-slate-400">EMEF Desembargador Pedro de Queiroz</span>
          </div>

          <div className="p-4 bg-black/60 rounded-lg my-3 font-mono text-xs text-emerald-400/90 leading-relaxed max-h-96 overflow-y-auto space-y-1">
            {terminalOutput.map((line, idx) => (
              <div key={idx} className={line.startsWith('[ERRO]') ? 'text-red-400' : line.startsWith('[SUCESSO]') || line.startsWith('[OK]') ? 'text-emerald-300 font-semibold' : line.startsWith('>>>') ? 'text-orange-400 font-bold' : ''}>
                {line}
              </div>
            ))}
          </div>

          {/* Quick test buttons */}
          <div className="pt-2 border-t border-slate-800/80">
            <div className="text-xs font-medium text-slate-300 mb-2">Executar comando no terminal:</div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => runTerminalCommand('1', 'Cadastrar')}
                className="px-3 py-1.5 rounded bg-blue-900/60 hover:bg-blue-800 text-xs font-mono text-blue-200 border border-blue-700/50 cursor-pointer"
              >
                1. Cadastrar Livro
              </button>
              <button
                onClick={() => runTerminalCommand('2', 'Listar')}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 border border-slate-700 cursor-pointer"
              >
                2. Listar Acervo
              </button>
              <button
                onClick={() => runTerminalCommand('6', 'Contador')}
                className="px-3 py-1.5 rounded bg-amber-900/50 hover:bg-amber-800 text-xs font-mono text-amber-200 border border-amber-700/50 cursor-pointer"
              >
                6. Contador de Acervo
              </button>
              <button
                onClick={() => runTerminalCommand('8', 'Notificações')}
                className="px-3 py-1.5 rounded bg-orange-900/60 hover:bg-orange-800 text-xs font-mono text-orange-200 border border-orange-700/50 cursor-pointer"
              >
                8. Notificações Atraso
              </button>
              <button
                onClick={() => runTerminalCommand('xml', 'Gerar XML')}
                className="px-3 py-1.5 rounded bg-emerald-900/50 hover:bg-emerald-800 text-xs font-mono text-emerald-200 border border-emerald-700/50 cursor-pointer"
              >
                Gerar XML Estruturado
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
