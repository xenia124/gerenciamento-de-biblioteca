import React from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Users, 
  Printer, 
  FileSpreadsheet, 
  ArrowRight, 
  Sparkles, 
  Layers, 
  GraduationCap, 
  Plus, 
  Send, 
  Library,
  ShieldCheck,
  Bookmark
} from 'lucide-react';
import { Livro, Usuario, Emprestimo, Assistente, EstatisticasAcervo } from '../types/library';
import { ESTANTES_PADRAO } from '../data/initialData';

interface DashboardViewProps {
  stats: EstatisticasAcervo;
  livros: Livro[];
  usuarios: Usuario[];
  emprestimos: Emprestimo[];
  assistenteAtivo?: Assistente;
  onNavigateTab: (tab: string) => void;
  onOpenNovoLivro: () => void;
  onOpenNovoEmprestimo: () => void;
  onOpenRelatorio: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  livros,
  usuarios,
  emprestimos,
  assistenteAtivo,
  onNavigateTab,
  onOpenNovoLivro,
  onOpenNovoEmprestimo,
  onOpenRelatorio,
}) => {
  const hoje = new Date().toISOString().split('T')[0];
  const emprestimosAtrasados = emprestimos.filter(
    e => e.status !== 'devolvido' && (e.status === 'atrasado' || e.dataPrevista < hoje)
  );

  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner - Clean Vector/Typographic School Identity (No AI Images) */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 text-white shadow-lg border border-blue-900 p-6 md:p-8">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-2.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-600/30 border border-orange-500/40 text-orange-300 text-xs font-semibold">
              <Library className="w-3.5 h-3.5 text-orange-400" />
              <span>EMEF Desembargador Pedro de Queiroz · Ano: 2026</span>
            </div>

            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
              Sistema de Cadastro de Biblioteca Valdiva Colaço
            </h1>

            <p className="text-xs md:text-sm text-blue-100/90 leading-relaxed">
              Projeto oficial: <strong>Xênia Cardoso</strong> · Bibliotecária: <strong>{assistenteAtivo?.nome || 'Ada Melo'}</strong>. Gestão de acervo real nas Estantes A-1, A-2 e A-3, controle de empréstimos e notificações de atraso.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={onOpenNovoLivro}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Livro</span>
            </button>

            <button
              onClick={onOpenNovoEmprestimo}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-blue-100 bg-white/10 hover:bg-white/20 border border-white/20 transition-all cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-orange-400" />
              <span>Empréstimo</span>
            </button>

            <button
              onClick={onOpenRelatorio}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-blue-100 bg-white/10 hover:bg-white/20 border border-white/20 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4 text-blue-300" />
              <span>Relatório PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Counter Statistics Strip (Etapa 6: Contador de Acervo) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Total Livros */}
        <div 
          onClick={() => onNavigateTab('acervo')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Total de Livros</span>
            <BookOpen className="w-4 h-4 text-blue-700" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {stats.totalLivros}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Fichas cadastradas no acervo oficial
          </div>
        </div>

        {/* Livros Disponíveis */}
        <div 
          onClick={() => onNavigateTab('acervo')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold text-emerald-800">Disponíveis</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 tabular-nums">
            {stats.livrosDisponiveis}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Prontos para retirada nas estantes
          </div>
        </div>

        {/* Livros Emprestados */}
        <div 
          onClick={() => onNavigateTab('emprestimos')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold text-blue-800">Em Circulação</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-900 tabular-nums">
            {stats.livrosEmprestados}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Em posse de alunos e professores
          </div>
        </div>

        {/* Livros em Atraso */}
        <div 
          onClick={() => onNavigateTab('notificacoes')}
          className={`p-5 rounded-xl border transition-all cursor-pointer ${
            stats.livrosAtrasados > 0
              ? 'bg-red-50/80 border-red-200 hover:border-red-300 hover:shadow-sm'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold text-red-700">Em Atraso</span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-red-600 tabular-nums">
            {stats.livrosAtrasados}
          </div>
          <div className="text-[11px] text-red-700 mt-1 font-medium">
            {stats.livrosAtrasados > 0 ? 'Notificações pendentes' : 'Nenhum atraso registrado'}
          </div>
        </div>
      </div>

      {/* Main Grid: Overdue Warnings + Shelves Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Overdue alerts & Shelves distribution */}
        <div className="space-y-6 lg:col-span-2">
          
          {/* Overdue alerts alert box */}
          {emprestimosAtrasados.length > 0 && (
            <div className="bg-white rounded-xl border border-orange-200 p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-orange-950 font-bold text-sm">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                  <span>Avisos de Devolução Pendentes ({emprestimosAtrasados.length})</span>
                </div>
                <button
                  onClick={() => onNavigateTab('notificacoes')}
                  className="text-xs font-semibold text-orange-700 hover:text-orange-900 inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Enviar Lembretes</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {emprestimosAtrasados.slice(0, 3).map((emp) => (
                  <div key={emp.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900">{emp.usuarioNome}</div>
                      <div className="text-[11px] text-slate-500">
                        {emp.livroTitulo} (Tombo: {emp.livroTombo}) · {emp.usuarioSerieTurma || emp.usuarioCategoria}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-[10px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">
                        Prazo: {emp.dataPrevista}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Physical Shelves A-1, A-2, A-3 preview */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Distribuição por Estante Física (A-1, A-2, A-3)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Mapeamento do cadastro oficial de livros da biblioteca
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('estantes')}
                className="text-xs font-semibold text-blue-900 hover:text-orange-600 inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Ver Mapa das Estantes</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {ESTANTES_PADRAO.map((est) => {
                const count = stats.estantesContagem[est.letra] || 0;
                return (
                  <div
                    key={est.letra}
                    onClick={() => onNavigateTab('estantes')}
                    className="p-3 rounded-lg border border-slate-100 bg-slate-50/60 hover:bg-orange-50/50 hover:border-orange-200 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="px-2 py-0.5 rounded bg-blue-900 text-white font-bold text-xs">
                        {est.letra}
                      </span>
                      <span className="text-xs font-mono font-bold text-slate-700">{count} {count === 1 ? 'obra' : 'obras'}</span>
                    </div>
                    <div className="text-[11px] font-semibold text-slate-800 truncate">
                      Estante {est.letra}
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {est.nome.split('·')[1] || est.nome}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Assistant Profile & Readers Breakdown */}
        <div className="space-y-6">
          {/* Card Assistente Oficial */}
          <div className="bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-xl p-5 shadow-sm space-y-4 border border-blue-900">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-orange-500 text-white font-bold flex items-center justify-center text-sm shadow">
                {(assistenteAtivo?.nome || 'Ada Melo').split(' ').map(n => n[0]).slice(0, 2).join('')}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">{assistenteAtivo?.nome || 'Ada Melo'}</h4>
                <p className="text-[11px] text-orange-200">{assistenteAtivo?.cargo || 'Bibliotecária'}</p>
              </div>
            </div>

            <p className="text-xs text-blue-100 leading-relaxed">
              "Bem-vindo(a) à Biblioteca Valdiva Colaço da EMEF Desembargador Pedro de Queiroz! Como bibliotecária, estou à disposição para guiar a consulta ao acervo e empréstimos."
            </p>

            <button
              onClick={() => onNavigateTab('assistente')}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold bg-orange-600 hover:bg-orange-500 text-white transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Gerenciar & Conversar com Bibliotecária</span>
            </button>
          </div>

          {/* Readers Breakdown Card */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                <Users className="w-4 h-4 text-blue-800" />
                <span>Leitores Cadastrados</span>
              </div>
              <button
                onClick={() => onNavigateTab('usuarios')}
                className="text-xs font-semibold text-blue-900 hover:text-orange-600 cursor-pointer"
              >
                Gerenciar
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-50">
                <span className="text-slate-600">Alunos e Alunas</span>
                <span className="font-bold text-slate-900 font-mono">{stats.totalAlunos}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-50">
                <span className="text-slate-600">Professores e Professoras</span>
                <span className="font-bold text-slate-900 font-mono">{stats.totalProfessores}</span>
              </div>
              <div className="flex items-center justify-between py-1.5">
                <span className="text-slate-600">Servidores Administrativos</span>
                <span className="font-bold text-slate-900 font-mono">{stats.totalServidores}</span>
              </div>
            </div>

            <div className="pt-2 text-[11px] text-slate-500">
              Total geral: <strong>{stats.totalUsuarios}</strong> leitores cadastrados
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
