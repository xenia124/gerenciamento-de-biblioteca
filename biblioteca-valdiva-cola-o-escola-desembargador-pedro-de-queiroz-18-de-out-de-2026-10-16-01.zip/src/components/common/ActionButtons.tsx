import React from 'react';
import { Check, ArrowLeft, X, Pencil, RotateCcw } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label?: string;
  icon?: boolean;
}

export const ConfirmarButton: React.FC<ButtonProps> = ({
  label = 'Confirmar',
  icon = true,
  className = '',
  ...props
}) => {
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 active:scale-[0.98] shadow-sm transition-all focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-1 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap shrink-0 ${className}`}
      {...props}
    >
      {icon && <Check className="w-4 h-4" />}
      <span>{label}</span>
    </button>
  );
};

export const VoltarButton: React.FC<ButtonProps> = ({
  label = 'Voltar',
  icon = true,
  className = '',
  ...props
}) => {
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 hover:text-slate-900 active:scale-[0.98] transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 cursor-pointer whitespace-nowrap shrink-0 ${className}`}
      {...props}
    >
      {icon && <ArrowLeft className="w-4 h-4 text-slate-500" />}
      <span>{label}</span>
    </button>
  );
};

export const CancelarButton: React.FC<ButtonProps> = ({
  label = 'Cancelar',
  icon = true,
  className = '',
  ...props
}) => {
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium text-slate-600 hover:text-red-700 hover:bg-red-50 bg-slate-100 border border-slate-200 active:scale-[0.98] transition-all focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-offset-1 cursor-pointer whitespace-nowrap shrink-0 ${className}`}
      {...props}
    >
      {icon && <X className="w-4 h-4 text-slate-500" />}
      <span>{label}</span>
    </button>
  );
};

export const CorrigirButton: React.FC<ButtonProps> = ({
  label = 'Corrigir',
  icon = true,
  className = '',
  ...props
}) => {
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium text-blue-900 bg-blue-50 border border-blue-200 hover:bg-blue-100 hover:border-blue-300 active:scale-[0.98] transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 cursor-pointer whitespace-nowrap shrink-0 ${className}`}
      {...props}
    >
      {icon && <Pencil className="w-4 h-4 text-blue-700" />}
      <span>{label}</span>
    </button>
  );
};

export const RestaurarButton: React.FC<ButtonProps> = ({
  label = 'Restaurar',
  icon = true,
  className = '',
  ...props
}) => {
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap shrink-0 ${className}`}
      {...props}
    >
      {icon && <RotateCcw className="w-3.5 h-3.5 text-slate-500" />}
      <span>{label}</span>
    </button>
  );
};
