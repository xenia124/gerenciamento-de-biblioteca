import React from 'react';
import { 
  Printer, 
  FileSpreadsheet, 
  FileCode, 
  X, 
  Download, 
  Building, 
  BookOpen, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { Livro, Usuario, Emprestimo, Assistente, EstatisticasAcervo } from '../types/library';
import { exportToCsv, exportToJson, exportToXml, downloadFile } from '../services/storageService';
import { ConfirmarButton, VoltarButton, CancelarButton } from './common/ActionButtons';

interface PrintReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  livros: Livro[];
  usuarios: Usuario[];
  emprestimos: Emprestimo[];
  assistenteAtivo?: Assistente;
  stats: EstatisticasAcervo;
}

export const PrintReportModal: React.FC<PrintReportModalProps> = ({
  isOpen,
  onClose,
  livros,
  usuarios,
  emprestimos,
  assistenteAtivo,
  stats,
}) => {
  if (!isOpen) return null;

  const dataAtual = new Date().toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
  const horaAtual = new Date().toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    exportToCsv(livros, emprestimos);
  };

  const handleExportXml = () => {
    const xml = exportToXml({
      livros,
      usuarios,
      emprestimos,
      assistentes: assistenteAtivo ? [assistenteAtivo] : [],
      assistenteAtivoId: assistenteAtivo?.id || '',
      ultimaModificacao: new Date().toISOString(),
    });
    downloadFile(xml, `relatorio_biblioteca_valdiva_${new Date().toISOString().split('T')[0]}.xml`, 'application/xml;charset=utf-8;');
  };

  const handleExportJson = () => {
    exportToJson({
      livros,
      usuarios,
      emprestimos,
      assistentes: assistenteAtivo ? [assistenteAtivo] : [],
      assistenteAtivoId: assistenteAtivo?.id || '',
      ultimaModificacao: new Date().toISOString(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-slate-300">
        
        {/* Top Control Bar (Hidden when printing) */}
        <div className="no-print p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-orange-400" />
            <h3 className="text-sm font-bold tracking-tight">
              Emissão de Relatório Oficial da Biblioteca Valdiva Colaço
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 shadow transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir / Salvar PDF</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-emerald-300 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 transition-all cursor-pointer"
              title="Baixar em formato Excel/CSV"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Excel (CSV)</span>
            </button>

            <button
              onClick={handleExportXml}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-blue-300 bg-blue-950/80 hover:bg-blue-900 border border-blue-700/60 transition-all cursor-pointer"
              title="Baixar em formato XML estruturado"
            >
              <FileCode className="w-4 h-4" />
              <span>XML</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet */}
        <div className="flex-1 overflow-y-auto p-8 bg-white print:p-0 print:m-0 font-['Montserrat',sans-serif] text-slate-900 text-xs">
          
          {/* Institutional Header */}
          <div className="border-b-2 border-slate-900 pb-4 mb-6 text-center space-y-1">
            <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500">
              SECRETARIA MUNICIPAL DE EDUCAÇÃO · GESTÃO ESCOLAR 2026
            </p>
            <h1 className="text-lg md:text-xl font-extrabold text-blue-950 tracking-tight">
              EMEF DESEMBARGADOR PEDRO DE QUEIROZ
            </h1>
            <h2 className="text-sm md:text-base font-bold text-orange-700 tracking-tight">
              BIBLIOTECA ESCOLAR VALDIVA COLAÇO
            </h2>
            <p className="text-[11px] text-slate-600 font-medium">
              Relatório Geral do Cadastro de Livros, Circulação e Notificações de Devolução
            </p>
            <div className="text-[10px] text-slate-500 pt-1">
              Projeto: <strong>Xênia Cardoso (Ano: 2026)</strong> · Bibliotecária Responsável: <strong>{assistenteAtivo?.nome || 'Ada Melo'}</strong>
            </div>
            <div className="text-[10px] text-slate-500">
              Data de Emissão: <strong>{dataAtual}</strong> às <strong>{horaAtual}</strong>
            </div>
          </div>

          {/* Key Indicators Summary Strip */}
          <div className="grid grid-cols-4 gap-3 mb-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-center border-r border-slate-200 pr-2">
              <div className="text-[10px] uppercase text-slate-500 font-semibold">Total de Livros</div>
              <div className="text-lg font-bold text-slate-900 font-mono mt-0.5">{stats.totalLivros}</div>
            </div>
            <div className="text-center border-r border-slate-200 pr-2">
              <div className="text-[10px] uppercase text-emerald-700 font-semibold">Obras Disponíveis</div>
              <div className="text-lg font-bold text-emerald-700 font-mono mt-0.5">{stats.livrosDisponiveis}</div>
            </div>
            <div className="text-center border-r border-slate-200 pr-2">
              <div className="text-[10px] uppercase text-blue-800 font-semibold">Em Circulação</div>
              <div className="text-lg font-bold text-blue-900 font-mono mt-0.5">{stats.livrosEmprestados}</div>
            </div>
            <div className="text-center">
              <div className="text-[10px] uppercase text-red-600 font-semibold">Em Atraso</div>
              <div className="text-lg font-bold text-red-600 font-mono mt-0.5">{stats.livrosAtrasados}</div>
            </div>
          </div>

          {/* Books Inventory Table */}
          <div className="mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2 border-b border-slate-200 pb-1 flex items-center justify-between">
              <span>Inventário Oficial do Acervo (Estantes A-1, A-2, A-3 e Setores)</span>
              <span className="font-normal text-slate-500">{livros.length} registros</span>
            </h3>
            
            <table className="w-full text-left border-collapse border border-slate-200 text-[11px]">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <th className="p-2 border-r border-slate-200 w-16">Tombo</th>
                  <th className="p-2 border-r border-slate-200">Título da Obra</th>
                  <th className="p-2 border-r border-slate-200">Autor</th>
                  <th className="p-2 border-r border-slate-200 text-center">Ano</th>
                  <th className="p-2 border-r border-slate-200">Gênero</th>
                  <th className="p-2 border-r border-slate-200 text-center">Estante</th>
                  <th className="p-2 text-center">Disponível</th>
                </tr>
              </thead>
              <tbody>
                {livros.map((livro, idx) => (
                  <tr key={livro.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}>
                    <td className="p-2 border-r border-slate-200 font-mono text-[10px] font-bold text-blue-900">{livro.tombo}</td>
                    <td className="p-2 border-r border-slate-200 font-semibold text-slate-900">{livro.titulo}</td>
                    <td className="p-2 border-r border-slate-200 text-slate-600">{livro.autor}</td>
                    <td className="p-2 border-r border-slate-200 text-center font-mono">{livro.ano}</td>
                    <td className="p-2 border-r border-slate-200 text-slate-600">{livro.genero}</td>
                    <td className="p-2 border-r border-slate-200 text-center font-semibold text-slate-700">{livro.estanteLetra}</td>
                    <td className="p-2 text-center font-bold">
                      <span className={livro.disponivel === 'Sim' ? 'text-emerald-700' : 'text-orange-700'}>
                        {livro.disponivel}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Active Loans & Delay Registry */}
          <div className="mb-8">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2 border-b border-slate-200 pb-1">
              Registro de Empréstimos e Devoluções
            </h3>

            <table className="w-full text-left border-collapse border border-slate-200 text-[11px]">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <th className="p-2 border-r border-slate-200">Livro / Tombo</th>
                  <th className="p-2 border-r border-slate-200">Leitor</th>
                  <th className="p-2 border-r border-slate-200">Categoria / Turma</th>
                  <th className="p-2 border-r border-slate-200 text-center">Data Empréstimo</th>
                  <th className="p-2 border-r border-slate-200 text-center">Prazo Previsto</th>
                  <th className="p-2 text-center">Situação</th>
                </tr>
              </thead>
              <tbody>
                {emprestimos.filter(e => e.status !== 'devolvido').map((e, idx) => (
                  <tr key={e.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}>
                    <td className="p-2 border-r border-slate-200 font-medium">{e.livroTitulo} ({e.livroTombo})</td>
                    <td className="p-2 border-r border-slate-200 font-semibold">{e.usuarioNome}</td>
                    <td className="p-2 border-r border-slate-200 text-slate-600">{e.usuarioSerieTurma || e.usuarioCategoria}</td>
                    <td className="p-2 border-r border-slate-200 text-center font-mono">{e.dataEmprestimo}</td>
                    <td className="p-2 border-r border-slate-200 text-center font-mono font-bold text-slate-800">{e.dataPrevista}</td>
                    <td className="p-2 text-center font-bold">
                      <span className={e.status === 'atrasado' ? 'text-red-700 bg-red-50 px-2 py-0.5 rounded' : 'text-blue-800'}>
                        {e.status === 'atrasado' ? `${e.diasAtraso || 1}d Atrasado` : 'Em Aberto'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Institutional Signatures */}
          <div className="pt-8 mt-12 border-t border-slate-300 grid grid-cols-3 gap-6 text-center">
            <div className="space-y-1">
              <div className="border-b border-slate-400 pb-2 w-3/4 mx-auto"></div>
              <div className="font-bold text-slate-900">{assistenteAtivo?.nome || 'Ada Melo'}</div>
              <div className="text-[10px] text-slate-500">{assistenteAtivo?.cargo || 'Bibliotecária'}</div>
              <div className="text-[10px] text-slate-400">Biblioteca Valdiva Colaço</div>
            </div>

            <div className="space-y-1">
              <div className="border-b border-slate-400 pb-2 w-3/4 mx-auto"></div>
              <div className="font-bold text-slate-900">Xênia Cardoso</div>
              <div className="text-[10px] text-slate-500">Coordenadora do Projeto Biblioteca 2026</div>
              <div className="text-[10px] text-slate-400">EMEF Des. Pedro de Queiroz</div>
            </div>

            <div className="space-y-1">
              <div className="border-b border-slate-400 pb-2 w-3/4 mx-auto"></div>
              <div className="font-bold text-slate-900">Direção Escolar</div>
              <div className="text-[10px] text-slate-500">EMEF Desembargador Pedro de Queiroz</div>
              <div className="text-[10px] text-slate-400">Secretaria Municipal de Educação</div>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls (Hidden when printing) */}
        <div className="no-print p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <VoltarButton label="Voltar ao Painel" onClick={onClose} />
          
          <div className="flex items-center gap-2">
            <CancelarButton label="Fechar" onClick={onClose} />
            <ConfirmarButton label="Imprimir Relatório (PDF)" onClick={handlePrint} />
          </div>
        </div>
      </div>
    </div>
  );
};
