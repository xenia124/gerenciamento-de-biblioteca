import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  Search, 
  GraduationCap, 
  Briefcase, 
  School, 
  Phone, 
  Mail, 
  Calendar,
  BookOpen,
  X,
  Pencil,
  Trash2,
  Clock
} from 'lucide-react';
import { Usuario, CategoriaUsuario, Emprestimo } from '../types/library';
import { SERIES_DISPONIVEIS, TURMAS_DISPONIVEIS, TURNOS_DISPONIVEIS } from '../data/initialData';
import { ConfirmarButton, VoltarButton, CancelarButton, CorrigirButton } from './common/ActionButtons';

interface UsuariosViewProps {
  usuarios: Usuario[];
  emprestimos: Emprestimo[];
  onSaveUsuario: (usuario: Usuario) => void;
  onDeleteUsuario: (usuarioId: string) => void;
}

export const UsuariosView: React.FC<UsuariosViewProps> = ({
  usuarios,
  emprestimos,
  onSaveUsuario,
  onDeleteUsuario,
}) => {
  const [termoBusca, setTermoBusca] = useState('');
  const [filtroCategoria, setFiltroCategoria] = useState<string>('todos');
  const [modalAberto, setModalAberto] = useState(false);
  const [usuarioEmEdicao, setUsuarioEmEdicao] = useState<Usuario | null>(null);

  // Form state
  const [nome, setNome] = useState('');
  const [matricula, setMatricula] = useState('');
  const [categoria, setCategoria] = useState<CategoriaUsuario>('aluno');
  const [serie, setSerie] = useState('1ª Série EM');
  const [turma, setTurma] = useState('A');
  const [turno, setTurno] = useState('Matutino');
  const [telefone, setTelefone] = useState('');
  const [email, setEmail] = useState('');

  const isAlunoOrAluna = categoria === 'aluno' || categoria === 'aluna';

  const handleOpenNovo = () => {
    setUsuarioEmEdicao(null);
    setNome('');
    setMatricula(`2026-${String(usuarios.length + 101).padStart(4, '0')}`);
    setCategoria('aluno');
    setSerie('1ª Série EM');
    setTurma('A');
    setTurno('Matutino');
    setTelefone('(85) 9');
    setEmail('');
    setModalAberto(true);
  };

  const handleOpenEditar = (u: Usuario) => {
    setUsuarioEmEdicao(u);
    setNome(u.nome);
    setMatricula(u.matricula);
    setCategoria(u.categoria);
    setSerie(u.serie || '1ª Série EM');
    setTurma(u.turma || 'A');
    setTurno(u.turno || 'Matutino');
    setTelefone(u.telefone);
    setEmail(u.email);
    setModalAberto(true);
  };

  const handleSalvar = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!nome.trim() || !matricula.trim()) {
      alert('Por favor, informe Nome e Matrícula.');
      return;
    }

    const payload: Usuario = {
      id: usuarioEmEdicao ? usuarioEmEdicao.id : `USR-${Date.now().toString().slice(-4)}`,
      matricula: matricula.trim(),
      nome: nome.trim(),
      categoria,
      serie: isAlunoOrAluna ? serie : undefined,
      turma: isAlunoOrAluna ? turma : undefined,
      turno: isAlunoOrAluna ? turno : undefined,
      telefone: telefone.trim() || '(85) 99000-0000',
      email: email.trim() || `${nome.toLowerCase().replace(/\s+/g, '.')}@escola.ce.gov.br`,
      dataCadastro: usuarioEmEdicao ? usuarioEmEdicao.dataCadastro : new Date().toISOString().split('T')[0],
    };

    onSaveUsuario(payload);
    setModalAberto(false);
  };

  // Filtered users
  const usuariosFiltrados = usuarios.filter(u => {
    const matchTerm = 
      u.nome.toLowerCase().includes(termoBusca.toLowerCase()) ||
      u.matricula.toLowerCase().includes(termoBusca.toLowerCase()) ||
      (u.serie && u.serie.toLowerCase().includes(termoBusca.toLowerCase()));

    if (!matchTerm) return false;

    if (filtroCategoria === 'alunos') {
      return u.categoria === 'aluno' || u.categoria === 'aluna';
    }
    if (filtroCategoria === 'professores') {
      return u.categoria === 'professor' || u.categoria === 'professora';
    }
    if (filtroCategoria === 'servidores') {
      return u.categoria === 'servidor' || u.categoria === 'servidora';
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Cadastro e Gestão de Leitores da Escola
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Subclassificação de Professores, Servidores, Alunos e Alunas com série, turma e turno
          </p>
        </div>

        <button
          onClick={handleOpenNovo}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 shadow transition-all cursor-pointer whitespace-nowrap self-start"
        >
          <UserPlus className="w-4 h-4" />
          <span>Cadastrar Novo Leitor</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setFiltroCategoria('todos')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroCategoria === 'todos' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Todos ({usuarios.length})
          </button>
          <button
            onClick={() => setFiltroCategoria('alunos')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroCategoria === 'alunos' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Alunos & Alunas
          </button>
          <button
            onClick={() => setFiltroCategoria('professores')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroCategoria === 'professores' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Corpo Docente
          </button>
          <button
            onClick={() => setFiltroCategoria('servidores')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroCategoria === 'servidores' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Servidores
          </button>
        </div>

        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={termoBusca}
            onChange={(e) => setTermoBusca(e.target.value)}
            placeholder="Buscar por nome, matrícula ou série..."
            className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50"
          />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {usuariosFiltrados.map((u) => {
          const userLoans = emprestimos.filter(e => e.usuarioId === u.id && e.status !== 'devolvido');
          const hasOverdue = userLoans.some(e => e.status === 'atrasado');

          return (
            <div
              key={u.id}
              className="bg-white rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-sm transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    Matrícula: {u.matricula}
                  </span>

                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full capitalize ${
                    u.categoria.includes('alun')
                      ? 'bg-blue-100 text-blue-800'
                      : u.categoria.includes('prof')
                      ? 'bg-amber-100 text-amber-900'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {u.categoria}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900">
                  {u.nome}
                </h3>

                {/* Subclassificações do Aluno/Aluna */}
                {(u.categoria === 'aluno' || u.categoria === 'aluna') ? (
                  <div className="mt-2 p-2 bg-blue-50/70 rounded-lg text-xs border border-blue-100 space-y-0.5">
                    <div className="text-blue-900 font-semibold flex items-center gap-1.5">
                      <GraduationCap className="w-3.5 h-3.5 text-blue-700" />
                      <span>{u.serie} · Turma {u.turma}</span>
                    </div>
                    <div className="text-[11px] text-blue-700">
                      Turno: <strong>{u.turno}</strong>
                    </div>
                  </div>
                ) : (
                  <div className="mt-2 p-2 bg-slate-50 rounded-lg text-xs text-slate-600 border border-slate-200">
                    <span className="font-semibold text-slate-800">Quadro Escolar:</span> {u.categoria.includes('prof') ? 'Docente da EMEF Des. Pedro de Queiroz' : 'Servidor(a) Administrativo(a)'}
                  </div>
                )}

                {/* Contact info */}
                <div className="mt-3 space-y-1 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{u.telefone}</span>
                  </div>
                  <div className="flex items-center gap-1.5 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{u.email}</span>
                  </div>
                </div>

                {/* Loan status */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500">Empréstimos ativos:</span>
                  <span className={`font-bold ${hasOverdue ? 'text-red-600' : userLoans.length > 0 ? 'text-blue-800' : 'text-slate-600'}`}>
                    {userLoans.length} {userLoans.length === 1 ? 'livro' : 'livros'}
                    {hasOverdue && ' (Atraso!)'}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  onClick={() => handleOpenEditar(u)}
                  className="p-1.5 rounded-lg text-blue-800 hover:bg-blue-50 transition-colors cursor-pointer text-xs flex items-center gap-1 font-medium"
                  title="Editar leitor"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  <span>Editar</span>
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Deseja realmente remover o leitor ${u.nome}?`)) {
                      onDeleteUsuario(u.id);
                    }
                  }}
                  className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 transition-colors cursor-pointer text-xs flex items-center gap-1 font-medium"
                  title="Excluir leitor"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Excluir</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* User Modal */}
      {modalAberto && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full flex flex-col shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <School className="w-5 h-5 text-orange-400" />
                <h3 className="text-base font-bold">
                  {usuarioEmEdicao ? 'Editar Leitor Escolar' : 'Cadastrar Novo Leitor'}
                </h3>
              </div>
              <button
                onClick={() => setModalAberto(false)}
                className="p-2 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvar} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Nome Completo *</label>
                <input
                  type="text"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Ex: Mariana Costa Feitosa"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Nº de Matrícula *</label>
                  <input
                    type="text"
                    required
                    value={matricula}
                    onChange={(e) => setMatricula(e.target.value)}
                    placeholder="2024-0101"
                    className="w-full text-xs font-mono px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Categoria / Subclasse *</label>
                  <select
                    value={categoria}
                    onChange={(e) => setCategoria(e.target.value as CategoriaUsuario)}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-medium"
                  >
                    <option value="aluno">Aluno</option>
                    <option value="aluna">Aluna</option>
                    <option value="professor">Professor</option>
                    <option value="professora">Professora</option>
                    <option value="servidor">Servidor</option>
                    <option value="servidora">Servidora</option>
                  </select>
                </div>
              </div>

              {/* Subclassificações obrigatórias para Aluno / Aluna */}
              {isAlunoOrAluna && (
                <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-200 space-y-3">
                  <div className="text-[11px] font-bold text-blue-950 uppercase tracking-wider">
                    Subclassificação do Estudante
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-700">Série *</label>
                      <select
                        value={serie}
                        onChange={(e) => setSerie(e.target.value)}
                        className="w-full text-xs px-2 py-1.5 rounded border border-blue-300 bg-white"
                      >
                        {SERIES_DISPONIVEIS.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-700">Turma *</label>
                      <select
                        value={turma}
                        onChange={(e) => setTurma(e.target.value)}
                        className="w-full text-xs px-2 py-1.5 rounded border border-blue-300 bg-white"
                      >
                        {TURMAS_DISPONIVEIS.map(t => (
                          <option key={t} value={t}>Turma {t}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-700">Turno *</label>
                      <select
                        value={turno}
                        onChange={(e) => setTurno(e.target.value)}
                        className="w-full text-xs px-2 py-1.5 rounded border border-blue-300 bg-white"
                      >
                        {TURNOS_DISPONIVEIS.map(tu => (
                          <option key={tu} value={tu}>{tu}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Telefone / WhatsApp</label>
                  <input
                    type="text"
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="(85) 99123-4567"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">E-mail Institucional</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="leitor@escola.ce.gov.br"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </form>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <VoltarButton onClick={() => setModalAberto(false)} />
              <div className="flex items-center gap-2">
                <CancelarButton onClick={() => setModalAberto(false)} />
                <ConfirmarButton onClick={() => handleSalvar()} label="Confirmar" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
