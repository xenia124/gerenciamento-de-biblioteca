import React, { useState } from 'react';
import { 
  ArrowLeftRight, 
  PlusCircle, 
  Check, 
  RotateCcw, 
  Search, 
  Calendar, 
  Clock, 
  User, 
  BookOpen, 
  AlertCircle,
  X,
  FileCheck2
} from 'lucide-react';
import { Livro, Usuario, Emprestimo } from '../types/library';
import { ConfirmarButton, VoltarButton, CancelarButton, CorrigirButton } from './common/ActionButtons';

interface EmprestimosViewProps {
  livros: Livro[];
  usuarios: Usuario[];
  emprestimos: Emprestimo[];
  onNovoEmprestimo: (livroId: string, usuarioId: string, diasPrazo: number, observacoes?: string) => void;
  onDevolverLivro: (emprestimoId: string) => void;
}

export const EmprestimosView: React.FC<EmprestimosViewProps> = ({
  livros,
  usuarios,
  emprestimos,
  onNovoEmprestimo,
  onDevolverLivro,
}) => {
  const [modalAberto, setModalAberto] = useState(false);
  const [filtroStatus, setFiltroStatus] = useState<'todos' | 'ativos' | 'atrasados' | 'devolvidos'>('ativos');
  const [termoBusca, setTermoBusca] = useState('');

  // Form states for new loan
  const [livroSelecionadoId, setLivroSelecionadoId] = useState('');
  const [usuarioSelecionadoId, setUsuarioSelecionadoId] = useState('');
  const [prazoDias, setPrazoDias] = useState<number>(7);
  const [observacoes, setObservacoes] = useState('');

  const livrosDisponiveis = livros.filter(l => l.disponivel === 'Sim');

  const handleOpenModal = () => {
    setLivroSelecionadoId(livrosDisponiveis[0]?.id || '');
    setUsuarioSelecionadoId(usuarios[0]?.id || '');
    setPrazoDias(7);
    setObservacoes('');
    setModalAberto(true);
  };

  const handleConfirmarEmprestimo = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!livroSelecionadoId || !usuarioSelecionadoId) {
      alert('Selecione um livro disponível e um leitor.');
      return;
    }
    onNovoEmprestimo(livroSelecionadoId, usuarioSelecionadoId, prazoDias, observacoes);
    setModalAberto(false);
  };

  const hoje = new Date().toISOString().split('T')[0];

  const emprestimosFiltrados = emprestimos.filter(emp => {
    const matchTerm = 
      emp.livroTitulo.toLowerCase().includes(termoBusca.toLowerCase()) ||
      emp.usuarioNome.toLowerCase().includes(termoBusca.toLowerCase()) ||
      emp.livroTombo.toLowerCase().includes(termoBusca.toLowerCase());

    if (!matchTerm) return false;

    if (filtroStatus === 'ativos') {
      return emp.status === 'ativo';
    }
    if (filtroStatus === 'atrasados') {
      return emp.status === 'atrasado' || (emp.status !== 'devolvido' && emp.dataPrevista < hoje);
    }
    if (filtroStatus === 'devolvidos') {
      return emp.status === 'devolvido';
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Circulação: Empréstimos e Devoluções
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Controle do fluxo de saída, prazos limites e reintegração de obras às estantes
          </p>
        </div>

        <button
          onClick={handleOpenModal}
          disabled={livrosDisponiveis.length === 0}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 shadow transition-all cursor-pointer whitespace-nowrap self-start disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Realizar Novo Empréstimo</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setFiltroStatus('ativos')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroStatus === 'ativos' ? 'bg-white text-blue-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Em Aberto ({emprestimos.filter(e => e.status === 'ativo').length})
          </button>
          <button
            onClick={() => setFiltroStatus('atrasados')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroStatus === 'atrasados' ? 'bg-red-600 text-white shadow-sm font-semibold' : 'text-red-700 hover:text-red-800'
            }`}
          >
            Atrasados ({emprestimos.filter(e => e.status === 'atrasado' || (e.status !== 'devolvido' && e.dataPrevista < hoje)).length})
          </button>
          <button
            onClick={() => setFiltroStatus('devolvidos')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroStatus === 'devolvidos' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Histórico / Devolvidos
          </button>
          <button
            onClick={() => setFiltroStatus('todos')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filtroStatus === 'todos' ? 'bg-white text-slate-900 shadow-sm font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Todos ({emprestimos.length})
          </button>
        </div>

        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={termoBusca}
            onChange={(e) => setTermoBusca(e.target.value)}
            placeholder="Buscar por leitor, título ou tombo..."
            className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50"
          />
        </div>
      </div>

      {/* Loans Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {emprestimosFiltrados.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <FileCheck2 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold">Nenhum empréstimo encontrado nesta visualização.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="p-3 pl-4">Livro / Tombo</th>
                  <th className="p-3">Leitor Responsável</th>
                  <th className="p-3">Data Empréstimo</th>
                  <th className="p-3">Prazo Previsto</th>
                  <th className="p-3">Situação</th>
                  <th className="p-3 pr-4 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {emprestimosFiltrados.map((emp) => {
                  const isAtrasado = emp.status === 'atrasado' || (emp.status !== 'devolvido' && emp.dataPrevista < hoje);
                  const isDevolvido = emp.status === 'devolvido';

                  return (
                    <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 pl-4">
                        <div className="font-bold text-slate-900">{emp.livroTitulo}</div>
                        <div className="font-mono text-[10px] text-slate-500">{emp.livroTombo}</div>
                      </td>

                      <td className="p-3">
                        <div className="font-semibold text-slate-900">{emp.usuarioNome}</div>
                        <div className="text-[11px] text-slate-500">
                          {emp.usuarioSerieTurma || emp.usuarioCategoria}
                        </div>
                      </td>

                      <td className="p-3 font-mono text-slate-600">
                        {emp.dataEmprestimo}
                      </td>

                      <td className="p-3 font-mono font-medium">
                        <span className={isAtrasado ? 'text-red-600 font-bold' : 'text-slate-800'}>
                          {emp.dataPrevista}
                        </span>
                      </td>

                      <td className="p-3">
                        {isDevolvido ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span>Devolvido em {emp.dataDevolucao}</span>
                          </span>
                        ) : isAtrasado ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">
                            <Clock className="w-3 h-3 text-red-600" />
                            <span>Atrasado ({emp.diasAtraso || 1} dias)</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-800 bg-blue-50 px-2 py-0.5 rounded">
                            <Clock className="w-3 h-3 text-blue-600" />
                            <span>Em Aberto</span>
                          </span>
                        )}
                      </td>

                      <td className="p-3 pr-4 text-right">
                        {!isDevolvido && (
                          <button
                            onClick={() => onDevolverLivro(emp.id)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-orange-600 transition-all cursor-pointer shadow-sm"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Devolver</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* New Loan Modal */}
      {modalAberto && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full flex flex-col shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ArrowLeftRight className="w-5 h-5 text-orange-400" />
                <h3 className="text-base font-bold">Realizar Empréstimo de Livro</h3>
              </div>
              <button
                onClick={() => setModalAberto(false)}
                className="p-2 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmarEmprestimo} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Selecione o Livro Disponível *</label>
                {livrosDisponiveis.length === 0 ? (
                  <p className="text-red-600 font-medium">Nenhum livro disponível no momento.</p>
                ) : (
                  <select
                    value={livroSelecionadoId}
                    onChange={(e) => setLivroSelecionadoId(e.target.value)}
                    className="w-full text-xs px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-medium"
                  >
                    {livrosDisponiveis.map(liv => (
                      <option key={liv.id} value={liv.id}>
                        {liv.titulo} - {liv.autor} ({liv.tombo}) [{liv.estanteLetra}]
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Selecione o Leitor Cadastrado *</label>
                <select
                  value={usuarioSelecionadoId}
                  onChange={(e) => {
                    setUsuarioSelecionadoId(e.target.value);
                    const user = usuarios.find(u => u.id === e.target.value);
                    if (user && (user.categoria === 'professor' || user.categoria === 'professora')) {
                      setPrazoDias(14); // 14 days for teachers
                    } else {
                      setPrazoDias(7);  // 7 days for students
                    }
                  }}
                  className="w-full text-xs px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-medium"
                >
                  {usuarios.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.nome} ({u.categoria.toUpperCase()}{u.serie ? ` - ${u.serie} ${u.turma}` : ''})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Prazo de Devolução *</label>
                  <select
                    value={prazoDias}
                    onChange={(e) => setPrazoDias(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value={7}>7 dias (Padrão Alunos)</option>
                    <option value={14}>14 dias (Padrão Professores)</option>
                    <option value={21}>21 dias (Projetos Especiais)</option>
                    <option value={30}>30 dias (Férias / Pesquisa)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Data de Saída</label>
                  <input
                    type="text"
                    disabled
                    value={hoje}
                    className="w-full text-xs font-mono px-3 py-2 rounded-lg border border-slate-200 bg-slate-100 text-slate-600"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Observações Pedagógicas</label>
                <textarea
                  rows={2}
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Ex: Leitura para redação, trabalho de história, etc."
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </form>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <VoltarButton onClick={() => setModalAberto(false)} />
              <div className="flex items-center gap-2">
                <CancelarButton onClick={() => setModalAberto(false)} />
                <ConfirmarButton onClick={() => handleConfirmarEmprestimo()} label="Confirmar Empréstimo" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
