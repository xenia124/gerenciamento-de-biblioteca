import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  Sparkles, 
  BookOpen, 
  Check, 
  Layers, 
  Barcode, 
  Loader2,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { Livro, StatusDisponibilidade } from '../types/library';
import { ESTANTES_PADRAO, GENEROS_LIVROS } from '../data/initialData';
import { searchBooksApi, BookApiResult } from '../services/bookApiService';
import { ConfirmarButton, CancelarButton, CorrigirButton, VoltarButton } from './common/ActionButtons';

interface LivroModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (livro: Livro) => void;
  livroParaEditar?: Livro | null;
  defaultEstanteLetra?: string;
  totalLivrosAtual: number;
}

export const LivroModal: React.FC<LivroModalProps> = ({
  isOpen,
  onClose,
  onSave,
  livroParaEditar,
  defaultEstanteLetra = 'A-1',
  totalLivrosAtual,
}) => {
  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [ano, setAno] = useState<number>(new Date().getFullYear());
  const [genero, setGenero] = useState('Infantojuvenil');
  const [estanteLetra, setEstanteLetra] = useState('A-1');
  const [secao, setSecao] = useState('A-1');
  const [tombo, setTombo] = useState('');
  const [disponivel, setDisponivel] = useState<StatusDisponibilidade>('Sim');
  const [isbn, setIsbn] = useState('');
  const [editora, setEditora] = useState('Escolar');
  const [sinopse, setSinopse] = useState('');
  const [paginas, setPaginas] = useState<number>(48);

  // Book API Search State
  const [apiQuery, setApiQuery] = useState('');
  const [isSearchingApi, setIsSearchingApi] = useState(false);
  const [apiResults, setApiResults] = useState<BookApiResult[]>([]);
  const [apiError, setApiError] = useState('');

  useEffect(() => {
    if (livroParaEditar) {
      setTitulo(livroParaEditar.titulo);
      setAutor(livroParaEditar.autor);
      setAno(livroParaEditar.ano);
      setGenero(livroParaEditar.genero);
      setEstanteLetra(livroParaEditar.estanteLetra || 'A-1');
      setSecao(livroParaEditar.secao || 'A-1');
      setTombo(livroParaEditar.tombo);
      setDisponivel(livroParaEditar.disponivel);
      setIsbn(livroParaEditar.isbn || '');
      setEditora(livroParaEditar.editora || 'Escolar');
      setSinopse(livroParaEditar.sinopse || '');
      setPaginas(livroParaEditar.paginas || 48);
    } else {
      // New book - sequence in 4-digit Tombo matching scanned sheet format
      resetForm();
      const nextNum = Math.max(167, totalLivrosAtual + 1);
      setTombo(String(nextNum).padStart(4, '0'));
      setEstanteLetra(defaultEstanteLetra || 'A-1');
      setSecao(defaultEstanteLetra || 'A-1');
    }
  }, [livroParaEditar, isOpen, totalLivrosAtual, defaultEstanteLetra]);

  const resetForm = () => {
    setTitulo('');
    setAutor('');
    setAno(new Date().getFullYear());
    setGenero('Infantojuvenil');
    setEstanteLetra(defaultEstanteLetra || 'A-1');
    setSecao(defaultEstanteLetra || 'A-1');
    setDisponivel('Sim');
    setIsbn('');
    setEditora('Escolar');
    setSinopse('');
    setPaginas(48);
    setApiResults([]);
    setApiQuery('');
  };

  const handleApiSearch = async () => {
    if (!apiQuery.trim()) return;
    setIsSearchingApi(true);
    setApiError('');
    try {
      const results = await searchBooksApi(apiQuery);
      setApiResults(results);
      if (results.length === 0) {
        setApiError('Nenhum resultado encontrado para este termo nas bases bibliográficas.');
      }
    } catch (err) {
      setApiError('Não foi possível conectar à API de livros no momento.');
    } finally {
      setIsSearchingApi(false);
    }
  };

  const handleSelectApiBook = (res: BookApiResult) => {
    setTitulo(res.titulo);
    setAutor(res.autor);
    setAno(res.ano);
    setEditora(res.editora || 'Escolar');
    setSinopse(res.sinopse);
    setIsbn(res.isbn);
    setPaginas(res.paginas || 48);

    if (res.genero.includes('Brasil')) {
      setGenero('Literatura Brasileira');
      setEstanteLetra('A-3');
      setSecao('A-3');
    } else if (res.genero.includes('Juvenil') || res.genero.includes('Child')) {
      setGenero('Infantojuvenil');
      setEstanteLetra('A-1');
      setSecao('A-1');
    }

    setApiResults([]);
    setApiQuery('');
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!titulo.trim() || !autor.trim()) {
      alert('Por favor, informe ao menos o Título e o Autor da obra.');
      return;
    }

    const estanteObj = ESTANTES_PADRAO.find(e => e.letra === estanteLetra) || ESTANTES_PADRAO[0];

    const novoOuAtualizado: Livro = {
      id: livroParaEditar ? livroParaEditar.id : `LIV-${Date.now().toString().slice(-4)}`,
      tombo: tombo || String(totalLivrosAtual + 1).padStart(4, '0'),
      titulo: titulo.trim(),
      autor: autor.trim(),
      ano: Number(ano) || 2026,
      disponivel,
      genero,
      estante: estanteObj.nome,
      estanteLetra,
      secao: secao || estanteLetra,
      isbn: isbn.trim(),
      editora: editora.trim() || 'Escolar',
      sinopse: sinopse.trim(),
      paginas: Number(paginas) || 48,
      dataCadastro: livroParaEditar ? livroParaEditar.dataCadastro : new Date().toISOString().split('T')[0],
    };

    onSave(novoOuAtualizado);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between border-b border-blue-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-600/30 border border-orange-400/40 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                {livroParaEditar ? 'Corrigir / Editar Cadastro de Livro' : 'Cadastro Oficial de Livro no Acervo'}
              </h3>
              <p className="text-xs text-blue-200">
                Biblioteca Valdiva Colaço · EMEF Desembargador Pedro de Queiroz (2026)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* API Search Quick-Fill Assistant */}
          <div className="p-4 bg-orange-50/70 rounded-xl border border-orange-200 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-orange-950 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-orange-600" />
              <span>Automação: Buscar dados catalográficos na API de Livros</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={apiQuery}
                onChange={(e) => setApiQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleApiSearch())}
                placeholder="Digite o título da obra (ex: 'Bisa Bia, Bisa Bel', 'A gaiola')..."
                className="flex-1 text-xs px-3.5 py-2.5 rounded-lg border border-orange-300 bg-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <button
                type="button"
                onClick={handleApiSearch}
                disabled={isSearchingApi || !apiQuery.trim()}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 transition-all cursor-pointer disabled:opacity-50 shrink-0"
              >
                {isSearchingApi ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                <span>Buscar na API</span>
              </button>
            </div>

            {apiError && (
              <p className="text-xs text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{apiError}</span>
              </p>
            )}

            {apiResults.length > 0 && (
              <div className="mt-2 space-y-2 max-h-48 overflow-y-auto border-t border-orange-200/80 pt-2">
                <div className="text-[11px] font-semibold text-slate-700">Selecione para preencher a ficha:</div>
                {apiResults.map((res, i) => (
                  <div
                    key={i}
                    onClick={() => handleSelectApiBook(res)}
                    className="p-2.5 bg-white hover:bg-orange-100/60 rounded-lg border border-orange-200 flex items-center justify-between gap-3 cursor-pointer transition-colors text-xs"
                  >
                    <div className="truncate">
                      <div className="font-bold text-slate-900 truncate">{res.titulo}</div>
                      <div className="text-[11px] text-slate-600 truncate">{res.autor} ({res.ano}) · {res.editora}</div>
                    </div>
                    <button
                      type="button"
                      className="px-2.5 py-1 rounded bg-orange-600 text-white font-semibold text-[10px] whitespace-nowrap"
                    >
                      Preencher
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Form Fields */}
          <form id="livro-form" onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2 space-y-1">
                <label className="text-xs font-bold text-slate-700">Título da Obra *</label>
                <input
                  type="text"
                  required
                  value={titulo}
                  onChange={(e) => setTitulo(e.target.value)}
                  placeholder="Ex: Caixa de Desejos, Bisa Bia, Bisa Bel"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Nº de Tombo Oficial (Ficha) *</label>
                <input
                  type="text"
                  required
                  value={tombo}
                  onChange={(e) => setTombo(e.target.value)}
                  placeholder="Ex: 0001, 0046, 0167"
                  className="w-full text-xs font-mono font-bold px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-blue-50/50 text-blue-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2 space-y-1">
                <label className="text-xs font-bold text-slate-700">Autor(a) *</label>
                <input
                  type="text"
                  required
                  value={autor}
                  onChange={(e) => setAutor(e.target.value)}
                  placeholder="Ex: Ana Maria Machado, Adriana Carranca"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Ano de Publicação *</label>
                <input
                  type="number"
                  required
                  value={ano}
                  onChange={(e) => setAno(parseInt(e.target.value) || 2026)}
                  placeholder="2026"
                  className="w-full text-xs font-mono px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Gênero Literário</label>
                <select
                  value={genero}
                  onChange={(e) => setGenero(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                >
                  {GENEROS_LIVROS.map((gen) => (
                    <option key={gen} value={gen}>{gen}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Estante (Ordem Alfabética A-Z) *</label>
                <select
                  value={estanteLetra}
                  onChange={(e) => {
                    setEstanteLetra(e.target.value);
                    setSecao(e.target.value);
                  }}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-medium"
                >
                  {ESTANTES_PADRAO.map((est) => (
                    <option key={est.letra} value={est.letra}>
                      {est.nome}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Status de Disponibilidade</label>
                <select
                  value={disponivel}
                  onChange={(e) => setDisponivel(e.target.value as StatusDisponibilidade)}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-semibold text-emerald-800"
                >
                  <option value="Sim">Sim (Disponível na Estante)</option>
                  <option value="Não">Não (Emprestado)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">ISBN (Opcional)</label>
                <input
                  type="text"
                  value={isbn}
                  onChange={(e) => setIsbn(e.target.value)}
                  placeholder="978-8535914849"
                  className="w-full text-xs font-mono px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Editora</label>
                <input
                  type="text"
                  value={editora}
                  onChange={(e) => setEditora(e.target.value)}
                  placeholder="Ex: Salamandra, Ática, Escolar"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Seção na Ficha Escolar</label>
                <input
                  type="text"
                  value={secao}
                  onChange={(e) => setSecao(e.target.value)}
                  placeholder="Ex: A-1, A-2, A-3"
                  className="w-full text-xs font-mono px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 font-semibold"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Observações / Sinopse da Obra</label>
              <textarea
                rows={3}
                value={sinopse}
                onChange={(e) => setSinopse(e.target.value)}
                placeholder="Breve descrição pedagógica ou anotação para a mediação escolar..."
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </form>
        </div>

        {/* Modal Action Controls: [confirmar, voltar, cancelar, corrigir] */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <VoltarButton onClick={onClose} label="Voltar" />

          <div className="flex items-center gap-2">
            <CorrigirButton onClick={resetForm} label="Corrigir / Limpar" />
            <CancelarButton onClick={onClose} label="Cancelar" />
            <ConfirmarButton
              onClick={() => handleSubmit()}
              label={livroParaEditar ? 'Confirmar Edição' : 'Confirmar Cadastro'}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
