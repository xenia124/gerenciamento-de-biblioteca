import React, { useState } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  BookOpen, 
  GraduationCap, 
  Clock, 
  HelpCircle, 
  MessageSquare,
  Library,
  Lightbulb,
  CheckCircle2,
  Plus,
  Trash2,
  UserCheck,
  User,
  ShieldCheck,
  X
} from 'lucide-react';
import { Livro, Usuario, Emprestimo, Assistente } from '../types/library';
import { ConfirmarButton, VoltarButton, CancelarButton, CorrigirButton } from './common/ActionButtons';

interface XeniaAssistantProps {
  livros: Livro[];
  usuarios: Usuario[];
  emprestimos: Emprestimo[];
  assistentes: Assistente[];
  assistenteAtivoId: string;
  onSelectAssistente: (id: string) => void;
  onAddAssistente: (novo: Assistente) => void;
  onDeleteAssistente: (id: string) => void;
  onSelectBook?: (livro: Livro) => void;
  onNavigateToTab?: (tab: string) => void;
}

interface Message {
  id: string;
  sender: 'assistente' | 'user';
  text: string;
  time: string;
  suggestions?: string[];
  recommendedBooks?: Livro[];
}

export const XeniaAssistant: React.FC<XeniaAssistantProps> = ({
  livros,
  usuarios,
  emprestimos,
  assistentes,
  assistenteAtivoId,
  onSelectAssistente,
  onAddAssistente,
  onDeleteAssistente,
  onSelectBook,
  onNavigateToTab
}) => {
  const [input, setInput] = useState('');
  const [modalNovoAberto, setModalNovoAberto] = useState(false);

  // New assistant form state
  const [novoNome, setNovoNome] = useState('');
  const [novoCargo, setNovoCargo] = useState('Bibliotecária');
  const [novaEspecialidade, setNovaEspecialidade] = useState('Organização de Acervo & Mediação');
  const [novaDescricao, setNovaDescricao] = useState('');

  const assistenteAtivo = assistentes.find(a => a.id === assistenteAtivoId) || assistentes[0];

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'assistente',
      text: `Olá! Sou ${assistenteAtivo?.nome || 'Ada Melo'} (${assistenteAtivo?.cargo || 'Bibliotecária'}). Atuo na Biblioteca Valdiva Colaço da EMEF Desembargador Pedro de Queiroz (Projeto: Xênia Cardoso - Ano: 2026). Como posso ajudar você hoje com as obras do nosso acervo nas estantes A-1, A-2 e A-3 ou controle de empréstimos?`,
      time: 'Agora',
      suggestions: [
        'Obras de Ana Maria Machado na Estante A-1',
        'Livros de Malala e Biografias no acervo',
        'Quais livros estão com devolução atrasada?',
        'Como estão organizadas as Estantes A-1, A-2 e A-3?'
      ]
    }
  ]);

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Generate intelligent response based on the active assistant and real catalog
    setTimeout(() => {
      const response = generateAssistantResponse(query.toLowerCase(), livros, usuarios, emprestimos, assistenteAtivo);
      setMessages(prev => [...prev, response]);
    }, 350);
  };

  const generateAssistantResponse = (
    q: string, 
    allBooks: Livro[], 
    allUsers: Usuario[], 
    allLoans: Emprestimo[],
    currentAssistant?: Assistente
  ): Message => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const id = (Date.now() + 1).toString();
    const nomeAssistente = currentAssistant?.nome || 'Ada Melo';

    // Check for delay/overdue loans
    if (q.includes('atrasad') || q.includes('atraso') || q.includes('notifica') || q.includes('prazo')) {
      const overdueLoans = allLoans.filter(l => l.status === 'atrasado');
      if (overdueLoans.length === 0) {
        return {
          id,
          sender: 'assistente',
          text: `Como ${nomeAssistente}, fico muito feliz em informar que todas as devoluções da EMEF Desembargador Pedro de Queiroz estão em dia! Não há pendências registradas no momento.`,
          time,
          suggestions: ['Ver acervo na Estante A-1', 'Buscar obras de Ana Maria Machado']
        };
      }
      return {
        id,
        sender: 'assistente',
        text: `Identifiquei ${overdueLoans.length} empréstimo(s) em atraso no acervo da Biblioteca Valdiva Colaço:\n\n${overdueLoans.map(o => `• ${o.livroTitulo} (Tombo: ${o.livroTombo}) com ${o.usuarioNome} (${o.usuarioSerieTurma || 'Leitor'}) - Previsão: ${o.dataPrevista}`).join('\n')}\n\nVocê pode gerar a notificação na aba "Atrasos" para envio aos estudantes ou docentes!`,
        time,
        suggestions: ['Ir para Notificações de Atraso', 'Ver livros disponíveis']
      };
    }

    // Author: Ana Maria Machado
    if (q.includes('ana maria machado') || q.includes('bisa bia') || q.includes('jabuti')) {
      const anaMaria = allBooks.filter(b => b.autor.toLowerCase().includes('ana maria machado'));
      return {
        id,
        sender: 'assistente',
        text: `Ana Maria Machado é uma das autoras mais representativas do acervo da Biblioteca Valdiva Colaço! Temos ${anaMaria.length} títulos catalogados nas estantes A-1, A-2 e A-3:`,
        time,
        recommendedBooks: anaMaria.slice(0, 6),
        suggestions: ['Bisa Bia, Bisa Bel', 'Raul da ferrugem azul', 'O Príncipe que bocejava']
      };
    }

    // Shelves A-1, A-2, A-3 physical organization
    if (q.includes('estante') || q.includes('organiza') || q.includes('a-1') || q.includes('a-2') || q.includes('a-3')) {
      return {
        id,
        sender: 'assistente',
        text: `A organização da Biblioteca Valdiva Colaço segue rigorosamente as fichas do Cadastro Oficial de Livros:\n\n• Estante A-1: Infantojuvenil e Narrativas (Tombos 0001 a 0062) com obras de Ana Cristina Melo, Ana Maria Machado, Adriana Carranca, Ângela Lago, etc.\n• Estante A-2: Fábulas, Clássicos e Poesia (Tombos 0063 a 0127) com Antoine de Saint-Exupéry, Ana Terra, Audrey Wood, Aluísio Azevedo.\n• Estante A-3: Literatura Brasileira e Regional (Tombos 0128 a 0166) com Ana Rita Rios, Angela Leite Souza, Adriano Bitarães Netto.\n• Estantes B, C, D: Demais acervos temáticos da EMEF Desembargador Pedro de Queiroz.`,
        time,
        suggestions: ['Ver acervo na Estante A-1', 'Ver acervo na Estante A-2', 'Ver acervo na Estante A-3']
      };
    }

    // Malala / Adriana Carranca
    if (q.includes('malala') || q.includes('adriana carranca')) {
      const malalaBooks = allBooks.filter(b => b.titulo.toLowerCase().includes('malala') || b.autor.toLowerCase().includes('carranca'));
      return {
        id,
        sender: 'assistente',
        text: `Temos exemplares da biografia "Malala, a menina que queria ir à escola" de Adriana Carranca registrados no acervo oficial (Tombos 0010, 0078, 0136), muito requisitada para projetos sobre cidadania e direitos humanos:`,
        time,
        recommendedBooks: malalaBooks,
        suggestions: ['Realizar Empréstimo', 'Ver Estante A-1']
      };
    }

    // General book search matching
    const matched = allBooks.filter(b => 
      q.includes(b.titulo.toLowerCase()) || 
      b.titulo.toLowerCase().includes(q) ||
      b.autor.toLowerCase().includes(q) ||
      b.tombo.includes(q)
    );

    if (matched.length > 0) {
      return {
        id,
        sender: 'assistente',
        text: `Encontrei ${matched.length} obra(s) catalogada(s) no acervo que correspondem à sua consulta:`,
        time,
        recommendedBooks: matched.slice(0, 6),
        suggestions: ['Como realizar o empréstimo?', 'Consultar outras estantes']
      };
    }

    // Friendly default
    return {
      id,
      sender: 'assistente',
      text: `Olá! Como ${nomeAssistente}, estou à disposição para apoiar os projetos pedagógicos e o empréstimo de livros na EMEF Desembargador Pedro de Queiroz (Projeto: Xênia Cardoso - 2026). Você pode pesquisar títulos pelo Tombo ou autor, emitir relatórios em PDF ou consultar as estantes A-1 a A-3.`,
      time,
      suggestions: [
        'Obras de Ana Maria Machado na Estante A-1',
        'Livros de Malala e Biografias no acervo',
        'Quais livros estão com devolução atrasada?',
        'Como estão organizadas as Estantes A-1, A-2 e A-3?'
      ]
    };
  };

  const handleSalvarNovoAssistente = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!novoNome.trim()) {
      alert('Informe o nome da bibliotecária.');
      return;
    }

    const novo: Assistente = {
      id: `AST-${Date.now().toString().slice(-4)}`,
      nome: novoNome.trim(),
      cargo: novoCargo.trim() || 'Bibliotecária',
      especialidade: novaEspecialidade.trim(),
      descricao: novaDescricao.trim() || `Bibliotecária da Biblioteca Valdiva Colaço da EMEF Desembargador Pedro de Queiroz (Ano 2026).`,
      ativo: false,
      dataCriacao: new Date().toISOString().split('T')[0],
    };

    onAddAssistente(novo);
    setModalNovoAberto(false);
    setNovoNome('');
    setNovaDescricao('');
  };

  const handleExcluirAssistente = (ast: Assistente) => {
    if (assistentes.length <= 1) {
      alert('É necessário manter pelo menos uma bibliotecária ativa no sistema.');
      return;
    }
    if (confirm(`Deseja realmente remover a bibliotecária "${ast.nome}"?`)) {
      onDeleteAssistente(ast.id);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Assistant Selection & Management ([adicionar/excluir novo assistente]) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-orange-700 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-orange-600" />
              <span>Corpo de Bibliotecárias & Gestão do Acervo (Ano: 2026)</span>
            </div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight mt-0.5">
              Gestão de Bibliotecárias da Biblioteca Valdiva Colaço
            </h2>
            <p className="text-xs text-slate-500">
              EMEF Desembargador Pedro de Queiroz · Projeto: Xênia Cardoso
            </p>
          </div>

          <button
            onClick={() => setModalNovoAberto(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 shadow-sm transition-all cursor-pointer whitespace-nowrap self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Nova Bibliotecária</span>
          </button>
        </div>

        {/* Assistant Cards Selector */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {assistentes.map((ast) => {
            const isActive = ast.id === assistenteAtivo?.id;

            return (
              <div
                key={ast.id}
                className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                  isActive
                    ? 'bg-blue-900 text-white border-blue-950 shadow-md ring-2 ring-orange-500'
                    : 'bg-slate-50 text-slate-800 border-slate-200 hover:border-blue-300'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                        isActive ? 'bg-orange-500 text-white' : 'bg-blue-100 text-blue-900'
                      }`}>
                        {ast.nome.split(' ').map(n => n[0]).slice(0, 2).join('')}
                      </div>
                      <div>
                        <div className={`text-xs font-bold leading-tight ${isActive ? 'text-white' : 'text-slate-900'}`}>
                          {ast.nome}
                        </div>
                        <div className={`text-[10px] ${isActive ? 'text-blue-200' : 'text-slate-500'}`}>
                          {ast.cargo}
                        </div>
                      </div>
                    </div>

                    {isActive ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-600 text-white shrink-0">
                        Ativo
                      </span>
                    ) : (
                      <button
                        onClick={() => onSelectAssistente(ast.id)}
                        className="text-[10px] font-semibold text-blue-800 bg-white hover:bg-blue-50 border border-slate-200 px-2 py-0.5 rounded cursor-pointer"
                      >
                        Ativar
                      </button>
                    )}
                  </div>

                  <p className={`text-[11px] line-clamp-2 mt-1 leading-relaxed ${isActive ? 'text-blue-100' : 'text-slate-600'}`}>
                    {ast.descricao}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-200/40 flex items-center justify-between text-[10px]">
                  <span className={`truncate mr-2 ${isActive ? 'text-blue-200' : 'text-slate-500'}`}>
                    {ast.especialidade}
                  </span>

                  {assistentes.length > 1 && (
                    <button
                      onClick={() => handleExcluirAssistente(ast)}
                      className={`p-1 rounded hover:bg-red-500/20 transition-colors cursor-pointer shrink-0 ${
                        isActive ? 'text-blue-300 hover:text-white' : 'text-slate-400 hover:text-red-600'
                      }`}
                      title="Excluir este assistente"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Chat with the Active Assistant */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[640px]">
        
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-blue-900 to-indigo-950 text-white p-4 border-b border-blue-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-500 text-white font-bold flex items-center justify-center text-sm shadow">
              {assistenteAtivo?.nome.split(' ').map(n => n[0]).slice(0, 2).join('')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white tracking-tight">
                  {assistenteAtivo?.nome || 'Ada Melo'}
                </h3>
                <span className="text-[10px] font-semibold text-orange-200 bg-orange-600/60 px-2 py-0.5 rounded-md">
                  {assistenteAtivo?.cargo || 'Bibliotecária'}
                </span>
              </div>
              <p className="text-[11px] text-blue-200">
                Biblioteca Valdiva Colaço · EMEF Desembargador Pedro de Queiroz (2026)
              </p>
            </div>
          </div>

          <div className="text-xs text-blue-200 hidden sm:flex items-center gap-2 bg-blue-950/60 px-3 py-1.5 rounded-lg border border-blue-800">
            <BookOpen className="w-3.5 h-3.5 text-orange-400" />
            <span>Acervo oficial: <strong>{livros.length}</strong> obras catalogadas</span>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-50/70">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] md:max-w-[75%] rounded-2xl p-4 shadow-sm ${
                msg.sender === 'user'
                  ? 'bg-blue-900 text-white rounded-tr-none'
                  : 'bg-white text-slate-800 border border-slate-200/80 rounded-tl-none'
              }`}>
                {msg.sender === 'assistente' && (
                  <div className="flex items-center gap-2 mb-2 pb-1.5 border-b border-slate-100 text-xs font-semibold text-blue-900">
                    <Library className="w-3.5 h-3.5 text-orange-600" />
                    <span>{assistenteAtivo?.nome}</span>
                    <span className="text-slate-400 font-normal text-[10px] ml-auto">{msg.time}</span>
                  </div>
                )}

                <p className="text-xs md:text-sm leading-relaxed whitespace-pre-line">
                  {msg.text}
                </p>

                {/* Recommended books list */}
                {msg.recommendedBooks && msg.recommendedBooks.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-100 space-y-2">
                    <div className="text-xs font-semibold text-blue-900 flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5 text-orange-600" />
                      <span>Obras do Cadastro Oficial:</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.recommendedBooks.map((book) => (
                        <div
                          key={book.id}
                          className="p-2.5 bg-slate-50 hover:bg-orange-50/50 rounded-lg border border-slate-200 transition-colors flex items-center justify-between text-xs"
                        >
                          <div className="truncate mr-2">
                            <div className="font-bold text-slate-900 truncate">{book.titulo}</div>
                            <div className="text-[11px] text-slate-500">{book.autor} · Tombo: {book.tombo}</div>
                            <div className="text-[10px] text-blue-800 font-medium">{book.estante}</div>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            book.disponivel === 'Sim' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {book.disponivel === 'Sim' ? 'Disponível' : 'Emprestado'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick suggestions chips */}
                {msg.suggestions && (
                  <div className="mt-3 pt-2 flex flex-wrap gap-1.5">
                    {msg.suggestions.map((sug, i) => (
                      <button
                        key={i}
                        onClick={() => handleSend(sug)}
                        className="text-[11px] font-medium text-blue-800 bg-blue-50 hover:bg-orange-100 hover:text-orange-900 border border-blue-200/80 px-2.5 py-1 rounded-md transition-colors cursor-pointer text-left"
                      >
                        {sug}
                      </button>
                    ))}
                  </div>
                )}

                {msg.sender === 'user' && (
                  <div className="text-right text-[10px] text-blue-200 mt-1">
                    {msg.time}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Consulte com ${assistenteAtivo?.nome || 'a bibliotecária'} (ex: 'Obras na Estante A-1', 'Atrasos')...`}
              className="flex-1 text-xs md:text-sm px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-slate-50"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-xs md:text-sm font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Enviar</span>
            </button>
          </form>
        </div>
      </div>

      {/* Modal: Adicionar Nova Bibliotecária */}
      {modalNovoAberto && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full flex flex-col shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <UserCheck className="w-5 h-5 text-orange-400" />
                <h3 className="text-base font-bold">Cadastrar Nova Bibliotecária</h3>
              </div>
              <button
                onClick={() => setModalNovoAberto(false)}
                className="p-2 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvarNovoAssistente} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Nome da Bibliotecária *</label>
                <input
                  type="text"
                  required
                  value={novoNome}
                  onChange={(e) => setNovoNome(e.target.value)}
                  placeholder="Ex: Ada Melo, Xênia Cardoso, etc."
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Cargo / Função *</label>
                  <input
                    type="text"
                    required
                    value={novoCargo}
                    onChange={(e) => setNovoCargo(e.target.value)}
                    placeholder="Ex: Bibliotecária, Orientador(a)"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Especialidade</label>
                  <input
                    type="text"
                    value={novaEspecialidade}
                    onChange={(e) => setNovaEspecialidade(e.target.value)}
                    placeholder="Ex: Mediação Literária, Acervo"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Descrição / Atribuições</label>
                <textarea
                  rows={3}
                  value={novaDescricao}
                  onChange={(e) => setNovaDescricao(e.target.value)}
                  placeholder="Descreva a atuação deste assistente na Biblioteca Valdiva Colaço..."
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </form>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <VoltarButton onClick={() => setModalNovoAberto(false)} />
              <div className="flex items-center gap-2">
                <CancelarButton onClick={() => setModalNovoAberto(false)} />
                <ConfirmarButton onClick={() => handleSalvarNovoAssistente()} label="Confirmar Cadastro" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
