import { Livro, Usuario, Emprestimo, Assistente, EstatisticasAcervo } from '../types/library';
import { LIVROS_INICIAIS, USUARIOS_INICIAIS, EMPRESTIMOS_INICIAIS, ASSISTENTES_INICIAIS } from '../data/initialData';

const STORAGE_KEY = 'valdiva_colaco_library_db_v3';

export interface DatabaseState {
  livros: Livro[];
  usuarios: Usuario[];
  emprestimos: Emprestimo[];
  assistentes: Assistente[];
  assistenteAtivoId: string;
  ultimaModificacao: string;
}

const sanitizeAssistentes = (list: Assistente[]): Assistente[] => {
  return list.map(a => {
    let cargo = a.cargo;
    if (!cargo || cargo.toLowerCase().includes('assistente de mediação') || cargo.toLowerCase().includes('mediadora de leitura')) {
      cargo = 'Bibliotecária';
    }
    return {
      ...a,
      cargo,
    };
  });
};

export const loadDatabase = (): DatabaseState => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('valdiva_colaco_library_db_v2');
    if (!raw) {
      const initial: DatabaseState = {
        livros: LIVROS_INICIAIS,
        usuarios: USUARIOS_INICIAIS,
        emprestimos: EMPRESTIMOS_INICIAIS,
        assistentes: ASSISTENTES_INICIAIS,
        assistenteAtivoId: ASSISTENTES_INICIAIS[0].id,
        ultimaModificacao: new Date().toISOString(),
      };
      saveDatabase(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    const assistentesLoaded = Array.isArray(parsed.assistentes) && parsed.assistentes.length > 0 
      ? sanitizeAssistentes(parsed.assistentes) 
      : ASSISTENTES_INICIAIS;

    return {
      livros: Array.isArray(parsed.livros) && parsed.livros.length > 0 ? parsed.livros : LIVROS_INICIAIS,
      usuarios: Array.isArray(parsed.usuarios) ? parsed.usuarios : USUARIOS_INICIAIS,
      emprestimos: Array.isArray(parsed.emprestimos) ? parsed.emprestimos : EMPRESTIMOS_INICIAIS,
      assistentes: assistentesLoaded,
      assistenteAtivoId: parsed.assistenteAtivoId || ASSISTENTES_INICIAIS[0].id,
      ultimaModificacao: parsed.ultimaModificacao || new Date().toISOString(),
    };
  } catch (err) {
    console.error('Falha ao carregar banco local, reiniciando dados padrão:', err);
    return {
      livros: LIVROS_INICIAIS,
      usuarios: USUARIOS_INICIAIS,
      emprestimos: EMPRESTIMOS_INICIAIS,
      assistentes: ASSISTENTES_INICIAIS,
      assistenteAtivoId: ASSISTENTES_INICIAIS[0].id,
      ultimaModificacao: new Date().toISOString(),
    };
  }
};

export const saveDatabase = (state: DatabaseState): void => {
  try {
    const payload = {
      ...state,
      ultimaModificacao: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch (err) {
    console.error('Falha ao persistir no localStorage:', err);
  }
};

export const resetDatabaseToDefaults = (): DatabaseState => {
  const initial: DatabaseState = {
    livros: LIVROS_INICIAIS,
    usuarios: USUARIOS_INICIAIS,
    emprestimos: EMPRESTIMOS_INICIAIS,
    assistentes: ASSISTENTES_INICIAIS,
    assistenteAtivoId: ASSISTENTES_INICIAIS[0].id,
    ultimaModificacao: new Date().toISOString(),
  };
  saveDatabase(initial);
  return initial;
};

// Calculates current statistics
export const calculateStats = (livros: Livro[], usuarios: Usuario[], emprestimos: Emprestimo[]): EstatisticasAcervo => {
  const totalLivros = livros.length;
  const livrosDisponiveis = livros.filter(l => l.disponivel === 'Sim').length;
  const livrosEmprestados = livros.filter(l => l.disponivel === 'Não').length;
  
  // Count active overdue loans
  const hoje = new Date().toISOString().split('T')[0];
  const livrosAtrasados = emprestimos.filter(
    e => e.status !== 'devolvido' && (e.status === 'atrasado' || e.dataPrevista < hoje)
  ).length;

  const totalUsuarios = usuarios.length;
  const totalAlunos = usuarios.filter(u => u.categoria === 'aluno' || u.categoria === 'aluna').length;
  const totalProfessores = usuarios.filter(u => u.categoria === 'professor' || u.categoria === 'professora').length;
  const totalServidores = usuarios.filter(u => u.categoria === 'servidor' || u.categoria === 'servidora').length;

  const estantesContagem: Record<string, number> = {};
  livros.forEach(l => {
    estantesContagem[l.estanteLetra] = (estantesContagem[l.estanteLetra] || 0) + 1;
  });

  const generosContagem: Record<string, number> = {};
  livros.forEach(l => {
    generosContagem[l.genero] = (generosContagem[l.genero] || 0) + 1;
  });

  return {
    totalLivros,
    livrosDisponiveis,
    livrosEmprestados,
    livrosAtrasados,
    totalUsuarios,
    totalAlunos,
    totalProfessores,
    totalServidores,
    estantesContagem,
    generosContagem,
  };
};

// Helper: Download a file in the browser
export const downloadFile = (content: string, filename: string, mimeType: string) => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// Export to JSON
export const exportToJson = (data: DatabaseState) => {
  const jsonContent = JSON.stringify(data, null, 2);
  downloadFile(jsonContent, `biblioteca_valdiva_colaco_${new Date().toISOString().split('T')[0]}.json`, 'application/json');
};

// Export to Valid XML
export const exportToXml = (data: DatabaseState): string => {
  const escapeXml = (unsafe?: string | number | null) => {
    if (unsafe === undefined || unsafe === null) return '';
    return String(unsafe)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  };

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<biblioteca>
  <metadados>
    <escola>EMEF Desembargador Pedro de Queiroz</escola>
    <nome>Biblioteca Valdiva Colaço</nome>
    <projeto>Xênia Cardoso</projeto>
    <ano>2026</ano>
    <dataExportacao>${new Date().toISOString()}</dataExportacao>
    <totalLivros>${data.livros.length}</totalLivros>
    <totalUsuarios>${data.usuarios.length}</totalUsuarios>
    <totalEmprestimos>${data.emprestimos.length}</totalEmprestimos>
  </metadados>
  <acervo>
${data.livros.map(l => `    <livro id="${escapeXml(l.id)}">
      <tombo>${escapeXml(l.tombo)}</tombo>
      <titulo>${escapeXml(l.titulo)}</titulo>
      <autor>${escapeXml(l.autor)}</autor>
      <ano>${l.ano}</ano>
      <genero>${escapeXml(l.genero)}</genero>
      <estante>${escapeXml(l.estante)}</estante>
      <estanteLetra>${escapeXml(l.estanteLetra)}</estanteLetra>
      <secao>${escapeXml(l.secao)}</secao>
      <disponivel>${escapeXml(l.disponivel)}</disponivel>
      <dataCadastro>${escapeXml(l.dataCadastro)}</dataCadastro>
    </livro>`).join('\n')}
  </acervo>
  <bibliotecarias>
${data.assistentes.map(a => `    <bibliotecaria id="${escapeXml(a.id)}">
      <nome>${escapeXml(a.nome)}</nome>
      <cargo>${escapeXml(a.cargo || 'Bibliotecária')}</cargo>
      <especialidade>${escapeXml(a.especialidade)}</especialidade>
    </bibliotecaria>`).join('\n')}
  </bibliotecarias>
  <usuarios>
${data.usuarios.map(u => `    <usuario id="${escapeXml(u.id)}">
      <matricula>${escapeXml(u.matricula)}</matricula>
      <nome>${escapeXml(u.nome)}</nome>
      <categoria>${escapeXml(u.categoria)}</categoria>
      ${u.serie ? `<serie>${escapeXml(u.serie)}</serie>` : ''}
      ${u.turma ? `<turma>${escapeXml(u.turma)}</turma>` : ''}
      ${u.turno ? `<turno>${escapeXml(u.turno)}</turno>` : ''}
      <telefone>${escapeXml(u.telefone)}</telefone>
      <email>${escapeXml(u.email)}</email>
    </usuario>`).join('\n')}
  </usuarios>
  <emprestimos>
${data.emprestimos.map(e => `    <emprestimo id="${escapeXml(e.id)}">
      <livroId>${escapeXml(e.livroId)}</livroId>
      <livroTitulo>${escapeXml(e.livroTitulo)}</livroTitulo>
      <livroTombo>${escapeXml(e.livroTombo)}</livroTombo>
      <usuarioNome>${escapeXml(e.usuarioNome)}</usuarioNome>
      <dataEmprestimo>${escapeXml(e.dataEmprestimo)}</dataEmprestimo>
      <dataPrevista>${escapeXml(e.dataPrevista)}</dataPrevista>
      <status>${escapeXml(e.status)}</status>
    </emprestimo>`).join('\n')}
  </emprestimos>
</biblioteca>`;

  return xml;
};

// Export to CSV / Excel compatible with UTF-8 BOM
export const exportToCsv = (livros: Livro[], emprestimos: Emprestimo[]) => {
  const activeLoansMap = new Map<string, Emprestimo>();
  emprestimos.filter(e => e.status !== 'devolvido').forEach(e => {
    activeLoansMap.set(e.livroId, e);
  });

  const headers = [
    'Tombo',
    'Titulo da Obra',
    'Autor',
    'Ano',
    'Genero',
    'Estante',
    'Secao',
    'Disponivel',
    'Editora',
    'Leitor Atual',
    'Categoria Leitor',
    'Data Emprestimo',
    'Data Prevista Devolucao',
    'Status Circulacao'
  ];

  const escapeCsvField = (field?: string | number | null) => {
    if (field === undefined || field === null) return '""';
    const str = String(field).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = livros.map(l => {
    const loan = activeLoansMap.get(l.id);
    return [
      escapeCsvField(l.tombo),
      escapeCsvField(l.titulo),
      escapeCsvField(l.autor),
      escapeCsvField(l.ano),
      escapeCsvField(l.genero),
      escapeCsvField(l.estante),
      escapeCsvField(l.secao || ''),
      escapeCsvField(l.disponivel),
      escapeCsvField(l.editora || ''),
      escapeCsvField(loan ? loan.usuarioNome : 'Nenhum'),
      escapeCsvField(loan ? loan.usuarioCategoria : '-'),
      escapeCsvField(loan ? loan.dataEmprestimo : '-'),
      escapeCsvField(loan ? loan.dataPrevista : '-'),
      escapeCsvField(loan ? (loan.status === 'atrasado' ? 'Atrasado' : 'Emprestado') : 'Disponível no Acervo')
    ].join(';');
  });

  // UTF-8 BOM ensures Excel displays accents (e.g., ç, ã, é) correctly without encoding issues
  const csvContent = '\uFEFF' + [headers.join(';'), ...rows].join('\r\n');
  downloadFile(csvContent, `acervo_biblioteca_valdiva_colaco_${new Date().toISOString().split('T')[0]}.csv`, 'text/csv;charset=utf-8;');
};
