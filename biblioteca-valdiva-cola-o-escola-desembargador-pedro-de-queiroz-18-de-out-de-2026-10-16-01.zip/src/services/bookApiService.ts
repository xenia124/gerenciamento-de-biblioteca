export interface BookApiResult {
  titulo: string;
  autor: string;
  ano: number;
  genero: string;
  editora: string;
  sinopse: string;
  isbn: string;
  capaUrl: string;
  paginas: number;
}

export const searchBooksApi = async (query: string): Promise<BookApiResult[]> => {
  if (!query || query.trim().length < 2) return [];

  const cleanQuery = query.trim();
  const results: BookApiResult[] = [];

  try {
    // 1. Try Google Books API
    const googleUrl = `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(cleanQuery)}&maxResults=8&langRestrict=pt`;
    const response = await fetch(googleUrl);
    
    if (response.ok) {
      const data = await response.json();
      if (data.items && Array.isArray(data.items)) {
        for (const item of data.items) {
          const info = item.volumeInfo || {};
          const publishedYear = info.publishedDate ? parseInt(info.publishedDate.substring(0, 4), 10) || 2020 : 2020;
          
          let isbn = '';
          if (info.industryIdentifiers && Array.isArray(info.industryIdentifiers)) {
            const isbn13 = info.industryIdentifiers.find((i: any) => i.type === 'ISBN_13');
            const isbn10 = info.industryIdentifiers.find((i: any) => i.type === 'ISBN_10');
            isbn = (isbn13 || isbn10 || info.industryIdentifiers[0])?.identifier || '';
          }

          let capa = '';
          if (info.imageLinks) {
            capa = info.imageLinks.thumbnail || info.imageLinks.smallThumbnail || '';
            // Ensure https protocol
            if (capa.startsWith('http://')) {
              capa = capa.replace('http://', 'https://');
            }
          }

          results.push({
            titulo: info.title || 'Título Desconhecido',
            autor: info.authors ? info.authors.join(', ') : 'Autor Desconhecido',
            ano: publishedYear,
            genero: (info.categories && info.categories[0]) || 'Literatura Geral',
            editora: info.publisher || 'Editora Escolar',
            sinopse: info.description || 'Sinopse não disponível na base de dados.',
            isbn: isbn,
            capaUrl: capa,
            paginas: info.pageCount || 100,
          });
        }
      }
    }
  } catch (err) {
    console.warn('Google Books API query failed, trying OpenLibrary fallback:', err);
  }

  // If no results from Google Books, try OpenLibrary API
  if (results.length === 0) {
    try {
      const olUrl = `https://openlibrary.org/search.json?q=${encodeURIComponent(cleanQuery)}&limit=6`;
      const olRes = await fetch(olUrl);
      if (olRes.ok) {
        const olData = await olRes.json();
        if (olData.docs && Array.isArray(olData.docs)) {
          for (const doc of olData.docs) {
            const coverId = doc.cover_i;
            const capa = coverId ? `https://covers.openlibrary.org/b/id/${coverId}-M.jpg` : '';
            results.push({
              titulo: doc.title || 'Título Desconhecido',
              autor: doc.author_name ? doc.author_name.join(', ') : 'Autor Desconhecido',
              ano: doc.first_publish_year || 2000,
              genero: doc.subject ? doc.subject[0] : 'Literatura Geral',
              editora: doc.publisher ? doc.publisher[0] : 'Editora Geral',
              sinopse: `Obra clássica catalogada no acervo Open Library internacional. Ano de primeira publicação: ${doc.first_publish_year || 'N/A'}.`,
              isbn: doc.isbn ? doc.isbn[0] : '',
              capaUrl: capa,
              paginas: doc.number_of_pages_median || 150,
            });
          }
        }
      }
    } catch (fallbackErr) {
      console.warn('OpenLibrary search fallback also failed:', fallbackErr);
    }
  }

  return results;
};
