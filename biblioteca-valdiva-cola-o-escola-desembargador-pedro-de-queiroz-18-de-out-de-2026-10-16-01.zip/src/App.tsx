/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Library, 
  ArrowLeftRight, 
  AlertTriangle, 
  Users, 
  FolderTree, 
  Bot, 
  Code2, 
  Printer, 
  RotateCcw,
  Plus,
  FileSpreadsheet,
  FileCode,
  CheckCircle2,
  Menu,
  X,
  ShieldCheck
} from 'lucide-react';
import { Livro, Usuario, Emprestimo, Assistente } from './types/library';
import { 
  loadDatabase, 
  saveDatabase, 
  resetDatabaseToDefaults, 
  calculateStats,
  exportToCsv,
  exportToJson,
  exportToXml,
  downloadFile
} from './services/storageService';
import { DashboardView } from './components/DashboardView';
import { AcervoView } from './components/AcervoView';
import { EmprestimosView } from './components/EmprestimosView';
import { NotificacoesAtrasoView } from './components/NotificacoesAtrasoView';
import { EstantesView } from './components/EstantesView';
import { UsuariosView } from './components/UsuariosView';
import { XeniaAssistant } from './components/XeniaAssistant';
import { PythonExplainer } from './components/PythonExplainer';
import { LivroModal } from './components/LivroModal';
import { LivroDetalhesModal } from './components/LivroDetalhesModal';
import { PrintReportModal } from './components/PrintReportModal';

export default function App() {
  const [dbState, setDbState] = useState(() => loadDatabase());
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'acervo' | 'emprestimos' | 'notificacoes' | 'estantes' | 'usuarios' | 'assistente' | 'python'
  >('dashboard');

  // Modals
  const [isLivroModalOpen, setIsLivroModalOpen] = useState(false);
  const [livroEmEdicao, setLivroEmEdicao] = useState<Livro | null>(null);
  const [defaultEstanteLetra, setDefaultEstanteLetra] = useState<string>('A-1');
  const [livroDetalhes, setLivroDetalhes] = useState<Livro | null>(null);
  const [isRelatorioModalOpen, setIsRelatorioModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Sync state to local storage whenever it changes
  useEffect(() => {
    saveDatabase(dbState);
  }, [dbState]);

  const stats = calculateStats(dbState.livros, dbState.usuarios, dbState.emprestimos);

  const assistenteAtivo = dbState.assistentes.find(a => a.id === dbState.assistenteAtivoId) || dbState.assistentes[0];

  // Handlers for Books
  const handleSaveLivro = (livro: Livro) => {
    setDbState(prev => {
      const exists = prev.livros.some(l => l.id === livro.id);
      let updatedLivros: Livro[];
      if (exists) {
        updatedLivros = prev.livros.map(l => l.id === livro.id ? livro : l);
      } else {
        updatedLivros = [livro, ...prev.livros];
      }
      return {
        ...prev,
        livros: updatedLivros,
      };
    });
  };

  const handleDeleteLivro = (livroId: string) => {
    setDbState(prev => ({
      ...prev,
      livros: prev.livros.filter(l => l.id !== livroId),
      // Clean associated loans if any
      emprestimos: prev.emprestimos.filter(e => e.livroId !== livroId),
    }));
  };

  // Handlers for Users
  const handleSaveUsuario = (usuario: Usuario) => {
    setDbState(prev => {
      const exists = prev.usuarios.some(u => u.id === usuario.id);
      let updatedUsuarios: Usuario[];
      if (exists) {
        updatedUsuarios = prev.usuarios.map(u => u.id === usuario.id ? usuario : u);
      } else {
        updatedUsuarios = [usuario, ...prev.usuarios];
      }
      return {
        ...prev,
        usuarios: updatedUsuarios,
      };
    });
  };

  const handleDeleteUsuario = (usuarioId: string) => {
    setDbState(prev => ({
      ...prev,
      usuarios: prev.usuarios.filter(u => u.id !== usuarioId),
    }));
  };

  // Handlers for Assistants [adicionar/excluir novo assistente]
  const handleSelectAssistente = (id: string) => {
    setDbState(prev => ({
      ...prev,
      assistenteAtivoId: id,
    }));
  };

  const handleAddAssistente = (novo: Assistente) => {
    setDbState(prev => ({
      ...prev,
      assistentes: [...prev.assistentes, novo],
      assistenteAtivoId: novo.id,
    }));
  };

  const handleDeleteAssistente = (id: string) => {
    setDbState(prev => {
      const filtered = prev.assistentes.filter(a => a.id !== id);
      return {
        ...prev,
        assistentes: filtered,
        assistenteAtivoId: prev.assistenteAtivoId === id ? (filtered[0]?.id || '') : prev.assistenteAtivoId,
      };
    });
  };

  // Handlers for Loans & Returns
  const handleNovoEmprestimo = (livroId: string, usuarioId: string, prazoDias: number, observacoes?: string) => {
    const livro = dbState.livros.find(l => l.id === livroId);
    const usuario = dbState.usuarios.find(u => u.id === usuarioId);
    if (!livro || !usuario) return;

    const dataEmprestimo = new Date().toISOString().split('T')[0];
    const dataPrevistaDate = new Date();
    dataPrevistaDate.setDate(dataPrevistaDate.getDate() + prazoDias);
    const dataPrevista = dataPrevistaDate.toISOString().split('T')[0];

    let usuarioSerieTurma = usuario.categoria.toUpperCase();
    if (usuario.serie) {
      usuarioSerieTurma = `${usuario.serie} - Turma ${usuario.turma || 'A'} (${usuario.turno || 'Matutino'})`;
    }

    const novoEmprestimo: Emprestimo = {
      id: `EMP-${Date.now().toString().slice(-4)}`,
      livroId: livro.id,
      livroTitulo: livro.titulo,
      livroTombo: livro.tombo,
      usuarioId: usuario.id,
      usuarioNome: usuario.nome,
      usuarioCategoria: usuario.categoria,
      usuarioTelefone: usuario.telefone,
      usuarioEmail: usuario.email,
      usuarioSerieTurma,
      dataEmprestimo,
      dataPrevista,
      status: 'ativo',
      observacoes: observacoes || '',
      notificacaoEnviada: false,
    };

    setDbState(prev => ({
      ...prev,
      livros: prev.livros.map(l => l.id === livroId ? { ...l, disponivel: 'Não' } : l),
      emprestimos: [novoEmprestimo, ...prev.emprestimos],
    }));
  };

  const handleDevolverLivro = (emprestimoId: string) => {
    const hoje = new Date().toISOString().split('T')[0];
    setDbState(prev => {
      const emprestimo = prev.emprestimos.find(e => e.id === emprestimoId);
      if (!emprestimo) return prev;

      return {
        ...prev,
        livros: prev.livros.map(l => l.id === emprestimo.livroId ? { ...l, disponivel: 'Sim' } : l),
        emprestimos: prev.emprestimos.map(e => e.id === emprestimoId ? {
          ...e,
          status: 'devolvido',
          dataDevolucao: hoje,
        } : e),
      };
    });
  };

  const handleMarcarNotificado = (emprestimoId: string) => {
    setDbState(prev => ({
      ...prev,
      emprestimos: prev.emprestimos.map(e => e.id === emprestimoId ? {
        ...e,
        notificacaoEnviada: true,
        dataUltimaNotificacao: new Date().toISOString().split('T')[0],
      } : e),
    }));
  };

  const handleResetData = () => {
    if (confirm('Deseja restaurar a base de dados para o cadastro oficial da escola (Tombos 0001 a 0166 e assistentes Ada Melo/Xênia Cardoso)?')) {
      const fresh = resetDatabaseToDefaults();
      setDbState(fresh);
    }
  };

  const activeLoanForBook = livroDetalhes 
    ? dbState.emprestimos.find(e => e.livroId === livroDetalhes.id && e.status !== 'devolvido') 
    : null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Montserrat',sans-serif]">
      
      {/* Institutional Top Bar (Zone 1: Wordmark, Zone 2: Navigation Links, Zone 3: Primary Action) */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-6">
          
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('dashboard')}
              className="flex items-center gap-2.5 text-left cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-900 to-indigo-950 flex items-center justify-center text-white shadow-sm border border-blue-900 group-hover:scale-105 transition-transform">
                <Library className="w-5 h-5 text-orange-400" />
              </div>
              <div className="leading-tight">
                <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap block">
                  Biblioteca Valdiva Colaço
                </span>
                <span className="text-[10px] text-slate-500 font-medium whitespace-nowrap hidden sm:block">
                  EMEF Desembargador Pedro de Queiroz · Projeto: Xênia Cardoso (2026)
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-600">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                activeTab === 'dashboard' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              Painel Geral
            </button>
            <button
              onClick={() => setActiveTab('acervo')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                activeTab === 'acervo' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              Acervo de Livros ({dbState.livros.length})
            </button>
            <button
              onClick={() => setActiveTab('emprestimos')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                activeTab === 'emprestimos' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              Empréstimos
            </button>
            <button
              onClick={() => setActiveTab('notificacoes')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'notificacoes' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              <span>Atrasos</span>
              {stats.livrosAtrasados > 0 && (
                <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center font-bold">
                  {stats.livrosAtrasados}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('estantes')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                activeTab === 'estantes' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              Estantes (A-1, A-2, A-3)
            </button>
            <button
              onClick={() => setActiveTab('usuarios')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                activeTab === 'usuarios' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              Leitores
            </button>
            <button
              onClick={() => setActiveTab('assistente')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer text-orange-700 flex items-center gap-1 ${
                activeTab === 'assistente' ? 'text-orange-700 border-orange-500' : 'border-transparent'
              }`}
            >
              <span>Bibliotecária ({assistenteAtivo?.nome.split(' ')[0]})</span>
            </button>
            <button
              onClick={() => setActiveTab('python')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer text-slate-700 flex items-center gap-1 font-mono ${
                activeTab === 'python' ? 'text-blue-900 border-orange-500' : 'border-transparent'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-blue-700" />
              <span>Python .py</span>
            </button>
          </nav>

          {/* Zone 3: Primary action button + Mobile Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setIsRelatorioModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-blue-900 to-indigo-900 hover:from-blue-800 hover:to-indigo-800 rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-orange-400" />
              <span className="hidden sm:inline">Relatório PDF</span>
              <span className="sm:hidden">PDF</span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Nav */}
        {mobileMenuOpen && (
          <div className="lg:hidden px-4 pt-2 pb-4 border-t border-slate-200 bg-white space-y-1 text-xs font-semibold">
            <button
              onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg ${activeTab === 'dashboard' ? 'bg-orange-50 text-orange-800' : 'text-slate-700'}`}
            >
              Painel Geral
            </button>
            <button
              onClick={() => { setActiveTab('acervo'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg ${activeTab === 'acervo' ? 'bg-orange-50 text-orange-800' : 'text-slate-700'}`}
            >
              Acervo de Livros ({dbState.livros.length})
            </button>
            <button
              onClick={() => { setActiveTab('emprestimos'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg ${activeTab === 'emprestimos' ? 'bg-orange-50 text-orange-800' : 'text-slate-700'}`}
            >
              Empréstimos
            </button>
            <button
              onClick={() => { setActiveTab('notificacoes'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg flex items-center justify-between ${activeTab === 'notificacoes' ? 'bg-orange-50 text-orange-800' : 'text-slate-700'}`}
            >
              <span>Notificações de Atraso</span>
              {stats.livrosAtrasados > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold">
                  {stats.livrosAtrasados}
                </span>
              )}
            </button>
            <button
              onClick={() => { setActiveTab('estantes'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg ${activeTab === 'estantes' ? 'bg-orange-50 text-orange-800' : 'text-slate-700'}`}
            >
              Estantes Físicas (A-1, A-2, A-3)
            </button>
            <button
              onClick={() => { setActiveTab('usuarios'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg ${activeTab === 'usuarios' ? 'bg-orange-50 text-orange-800' : 'text-slate-700'}`}
            >
              Leitores (Alunos, Professores, Servidores)
            </button>
            <button
              onClick={() => { setActiveTab('assistente'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg text-orange-700 ${activeTab === 'assistente' ? 'bg-orange-50 font-bold' : ''}`}
            >
              Bibliotecárias (Ada Melo / Xênia Cardoso)
            </button>
            <button
              onClick={() => { setActiveTab('python'); setMobileMenuOpen(false); }}
              className={`w-full text-left py-2 px-3 rounded-lg font-mono text-blue-900 ${activeTab === 'python' ? 'bg-blue-50 font-bold' : ''}`}
            >
              Código Python (Etapas 1 a 6)
            </button>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            stats={stats}
            livros={dbState.livros}
            usuarios={dbState.usuarios}
            emprestimos={dbState.emprestimos}
            assistenteAtivo={assistenteAtivo}
            onNavigateTab={(tab) => setActiveTab(tab as any)}
            onOpenNovoLivro={() => {
              setLivroEmEdicao(null);
              setDefaultEstanteLetra('A-1');
              setIsLivroModalOpen(true);
            }}
            onOpenNovoEmprestimo={() => setActiveTab('emprestimos')}
            onOpenRelatorio={() => setIsRelatorioModalOpen(true)}
          />
        )}

        {activeTab === 'acervo' && (
          <AcervoView
            livros={dbState.livros}
            onOpenNovoLivro={() => {
              setLivroEmEdicao(null);
              setDefaultEstanteLetra('A-1');
              setIsLivroModalOpen(true);
            }}
            onOpenEditarLivro={(livro) => {
              setLivroEmEdicao(livro);
              setIsLivroModalOpen(true);
            }}
            onDeleteLivro={handleDeleteLivro}
            onSelectLivroDetalhes={(livro) => setLivroDetalhes(livro)}
          />
        )}

        {activeTab === 'emprestimos' && (
          <EmprestimosView
            livros={dbState.livros}
            usuarios={dbState.usuarios}
            emprestimos={dbState.emprestimos}
            onNovoEmprestimo={handleNovoEmprestimo}
            onDevolverLivro={handleDevolverLivro}
          />
        )}

        {activeTab === 'notificacoes' && (
          <NotificacoesAtrasoView
            emprestimos={dbState.emprestimos}
            usuarios={dbState.usuarios}
            livros={dbState.livros}
            onRegistrarDevolucao={handleDevolverLivro}
            onMarcarNotificado={handleMarcarNotificado}
          />
        )}

        {activeTab === 'estantes' && (
          <EstantesView
            livros={dbState.livros}
            onSelectBook={(livro) => setLivroDetalhes(livro)}
            onOpenNovoLivro={(letra) => {
              setLivroEmEdicao(null);
              setDefaultEstanteLetra(letra || 'A-1');
              setIsLivroModalOpen(true);
            }}
          />
        )}

        {activeTab === 'usuarios' && (
          <UsuariosView
            usuarios={dbState.usuarios}
            emprestimos={dbState.emprestimos}
            onSaveUsuario={handleSaveUsuario}
            onDeleteUsuario={handleDeleteUsuario}
          />
        )}

        {activeTab === 'assistente' && (
          <XeniaAssistant
            livros={dbState.livros}
            usuarios={dbState.usuarios}
            emprestimos={dbState.emprestimos}
            assistentes={dbState.assistentes}
            assistenteAtivoId={dbState.assistenteAtivoId}
            onSelectAssistente={handleSelectAssistente}
            onAddAssistente={handleAddAssistente}
            onDeleteAssistente={handleDeleteAssistente}
            onSelectBook={(livro) => setLivroDetalhes(livro)}
            onNavigateToTab={(tab) => setActiveTab(tab as any)}
          />
        )}

        {activeTab === 'python' && (
          <PythonExplainer />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-6 px-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div className="font-semibold text-slate-800">
              Biblioteca Valdiva Colaço · EMEF Desembargador Pedro de Queiroz
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Projeto: <strong>Xênia Cardoso</strong> (Ano: <strong>2026</strong>) · Bibliotecária: <strong>{assistenteAtivo?.nome || 'Ada Melo'}</strong> · Cores Laranja & Azul · Fonte Montserrat
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => exportToCsv(dbState.livros, dbState.emprestimos)}
              className="text-slate-600 hover:text-blue-900 transition-colors cursor-pointer flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Exportar Excel</span>
            </button>
            <span>·</span>
            <button
              onClick={() => {
                const xml = exportToXml(dbState);
                downloadFile(xml, `biblioteca_valdiva_${new Date().toISOString().split('T')[0]}.xml`, 'application/xml;charset=utf-8;');
              }}
              className="text-slate-600 hover:text-blue-900 transition-colors cursor-pointer flex items-center gap-1"
            >
              <FileCode className="w-3.5 h-3.5 text-blue-600" />
              <span>XML Estruturado</span>
            </button>
            <span>·</span>
            <button
              onClick={handleResetData}
              className="text-slate-500 hover:text-red-700 transition-colors cursor-pointer flex items-center gap-1"
              title="Restaurar cadastro oficial"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Resetar Cadastro</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <LivroModal
        isOpen={isLivroModalOpen}
        onClose={() => {
          setIsLivroModalOpen(false);
          setLivroEmEdicao(null);
        }}
        onSave={handleSaveLivro}
        livroParaEditar={livroEmEdicao}
        defaultEstanteLetra={defaultEstanteLetra}
        totalLivrosAtual={dbState.livros.length}
      />

      <LivroDetalhesModal
        livro={livroDetalhes}
        emprestimoAtivo={activeLoanForBook}
        onClose={() => setLivroDetalhes(null)}
        onEditar={(livro) => {
          setLivroEmEdicao(livro);
          setIsLivroModalOpen(true);
        }}
        onIniciarEmprestimo={(livro) => {
          setActiveTab('emprestimos');
        }}
        onDevolver={(empId) => {
          handleDevolverLivro(empId);
        }}
      />

      <PrintReportModal
        isOpen={isRelatorioModalOpen}
        onClose={() => setIsRelatorioModalOpen(false)}
        livros={dbState.livros}
        usuarios={dbState.usuarios}
        emprestimos={dbState.emprestimos}
        assistenteAtivo={assistenteAtivo}
        stats={stats}
      />
    </div>
  );
}
