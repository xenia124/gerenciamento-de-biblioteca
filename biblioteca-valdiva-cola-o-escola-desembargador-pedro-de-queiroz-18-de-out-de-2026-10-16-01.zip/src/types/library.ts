export type CategoriaUsuario = 
  | 'aluno' 
  | 'aluna' 
  | 'professor' 
  | 'professora' 
  | 'servidor' 
  | 'servidora';

export type StatusDisponibilidade = 'Sim' | 'Não';

export interface Livro {
  id: string;
  tombo: string;        // ex: "0001", "0002", etc. da ficha oficial
  titulo: string;       // ex: "Caixa de Desejos", "Bisa Bia, Bisa Bel"
  autor: string;        // ex: "Ana Cristina Melo", "Ana Maria Machado"
  ano: number;          // ano de publicação
  disponivel: StatusDisponibilidade;
  genero: string;       // Infantojuvenil, Literatura Brasileira, Contos, etc.
  estante: string;      // ex: "Estante A-1", "Estante A-2", "Estante A-3"
  estanteLetra: string; // 'A' | 'B' | 'C' | 'D' | 'E' | 'F'
  secao?: string;       // ex: "A-1", "A-2", "A-3"
  isbn?: string;
  editora?: string;
  sinopse?: string;
  paginas?: number;
  dataCadastro: string;
}

export interface Usuario {
  id: string;
  matricula: string;
  nome: string;
  categoria: CategoriaUsuario;
  serie?: string; // ex: "1ª Série EM", "9º Ano EF"
  turma?: string; // ex: "A", "B", "C"
  turno?: string; // ex: "Matutino", "Vespertino", "Noturno", "Integral"
  telefone: string;
  email: string;
  dataCadastro: string;
}

export interface Emprestimo {
  id: string;
  livroId: string;
  livroTitulo: string;
  livroTombo: string;
  usuarioId: string;
  usuarioNome: string;
  usuarioCategoria: CategoriaUsuario;
  usuarioTelefone: string;
  usuarioEmail: string;
  usuarioSerieTurma?: string;
  dataEmprestimo: string; // YYYY-MM-DD
  dataPrevista: string;   // YYYY-MM-DD
  dataDevolucao?: string | null;
  status: 'ativo' | 'devolvido' | 'atrasado';
  diasAtraso?: number;
  observacoes?: string;
  notificacaoEnviada?: boolean;
  dataUltimaNotificacao?: string;
}

export interface Assistente {
  id: string;
  nome: string;
  cargo: string;
  descricao: string;
  especialidade: string;
  ativo?: boolean;
  dataCriacao: string;
}

export interface EstatisticasAcervo {
  totalLivros: number;
  livrosDisponiveis: number;
  livrosEmprestados: number;
  livrosAtrasados: number;
  totalUsuarios: number;
  totalAlunos: number;
  totalProfessores: number;
  totalServidores: number;
  estantesContagem: Record<string, number>;
  generosContagem: Record<string, number>;
}
