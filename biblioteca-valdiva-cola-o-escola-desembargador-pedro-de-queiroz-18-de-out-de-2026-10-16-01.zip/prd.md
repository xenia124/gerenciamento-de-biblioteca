# PRD - Sistema de Cadastro e Gestão de Biblioteca Escolar Valdiva Colaço
**Instituição de Ensino:** EMEF Desembargador Pedro de Queiroz  
**Projeto:** Xênia Cardoso  
**Ano de Referência:** 2026  
**Corpo de Assistentes & Mediação:** Ada Melo (Bibliotecária Responsável), Xênia Cardoso (Coordenadora de Projeto)  

---

## 1. Visão Geral do Produto
O **Sistema de Cadastro de Biblioteca Valdiva Colaço** foi concebido para modernizar a gestão do acervo físico, empréstimos, devoluções, notificações de atraso e relatórios institucionais da EMEF Desembargador Pedro de Queiroz. O sistema digitaliza o acervo catalogado nas fichas oficiais da escola (Tombos 0001 a 0166) distribuídas fisicamente nas Estantes A-1, A-2 e A-3.

## 2. Objetivos Principais
1. **Catalogação Real e Fiel:** Cadastro dos livros com números de tombo oficiais, títulos, autores e estantes físicas.
2. **Ciclo de Circulação:** Controle de empréstimos com alteração de status (`disponivel`: "Sim" / "Não"), cálculo dinâmico de dias em atraso e reintegração às estantes na devolução.
3. **Comunicação Ativa & Notificações:** Emissão de avisos amigáveis para WhatsApp e e-mail institucional para leitores com prazos vencidos.
4. **Assistência de Mediação de Leitura:** Interface interativa configurada com Ada Melo e Xênia Cardoso, com suporte à adição e remoção de assistentes.
5. **Relatórios e Interoperabilidade:** Exportação de relatórios em PDF com cabeçalho oficial e assinaturas, planilhas em formato Excel/CSV com codificação UTF-8 BOM, e estrutura de dados em XML e JSON válidos.
6. **Portfólio Pedagógico em Python:** Código-fonte limpo demonstrando as Etapas 1 a 6 com menus, funções, manipulação de arquivos e ordenações.

## 3. Personas & Usuários
- **Alunos e Alunas:** Identificados por matrícula escolar, série (6º ao 9º Ano EF, 1ª a 3ª Série EM, EJA), turma (A, B, C, D, Integral) e turno (Matutino, Vespertino, Noturno, Integral). Prazo padrão: 7 dias.
- **Professores e Professoras:** Docentes de diversas áreas da escola. Prazo padrão: 14 dias.
- **Servidores e Servidoras Administrativas:** Quadro de apoio pedagógico e secretaria.
- **Equipe da Biblioteca:** Ada Melo e Xênia Cardoso na supervisão de circulação e inventário.

## 4. Requisitos Funcionais
- **RF01 - Menu Principal:** Acesso às operações de cadastro, listagem, busca, empréstimo, devolução, estantes, relatórios e assistência.
- **RF02 - Cadastro de Obras:** Registro por número de Tombo (0001, 0002...), título, autor, ano, gênero, estante (A-1, A-2, A-3, B, C, D) e disponibilidade.
- **RF03 - Busca & Filtros:** Busca por Tombo, Título, Autor, Gênero e disponibilidade.
- **RF04 - Empréstimos & Devoluções:** Vinculação do livro ao leitor, alteração de status e devolução rápida.
- **RF05 - Notificações de Atraso:** Identificação de atrasos e geração de mensagem formatada para WhatsApp e e-mail.
- **RF06 - Gestão de Assistentes:** Adicionar, selecionar e excluir assistentes escolares.
- **RF07 - Exportação:** Geração de PDF oficial, CSV/Excel e XML bem formatado.

## 5. Requisitos Não Funcionais
- **Identidade Visual:** Cores Laranja e Azul, tipografia Montserrat, ausência de imagens fictícias geradas por IA, ícones minimalistas.
- **Componentes de Ação:** [Confirmar, Voltar, Cancelar, Corrigir].
