# Tarefas do Projeto - Biblioteca Valdiva Colaço
**EMEF Desembargador Pedro de Queiroz**  
**Projeto:** Xênia Cardoso | **Ano:** 2026  
**Assistente:** Ada Melo  

---

## Checklist de Etapas e Requisitos

### Etapa 1: Estrutura Inicial e Menu
- [x] Criação do menu principal interativo com opções de cadastro, listagem, busca, empréstimo, devolução e saída.
- [x] Estruturação modular com assinaturas de funções e uso de `pass` para garantir execução sem erros.

### Etapa 2: Cadastro de Livros
- [x] Representação de cada obra como dicionário contendo título, autor, ano, número de tombo oficial e disponibilidade ("Sim" / "Não").
- [x] Transcrição e carga do acervo oficial das fichas da escola (Tombos 0001 a 0166) nas estantes A-1, A-2 e A-3.
- [x] Armazenamento em memória através de lista global de dicionários.

### Etapa 3: Consulta e Busca
- [x] Listagem geral de todas as obras do acervo de forma organizada.
- [x] Busca avançada por filtros: Tombo, Título, Autor, Gênero e Estante.
- [x] Tratamento de erros e mensagens claras quando o item não for localizado.

### Etapa 4: Empréstimos e Devoluções
- [x] Lógica de empréstimo com alteração de status de `"Sim"` para `"Não"`.
- [x] Reversão rápida para `"Sim"` na devolução, reintegrando o livro à estante física.
- [x] Registro da data de saída e cálculo da data limite (7 dias para alunos, 14 para professores).

### Etapa 5: Persistência com JSON
- [x] Leitura de arquivo JSON ao iniciar o programa para popular o acervo.
- [x] Salvamento automático de todas as alterações (cadastro, empréstimo, devolução).
- [x] Opção de download do banco em formato JSON válido e padronizado.

### Etapa 6: Melhorias Avançadas
- [x] **Contador de Acervo:** Exibição da quantidade total de livros, livros disponíveis, livros emprestados e atrasados.
- [x] **Ordenação Múltipla:** Exibição em ordem alfabética por título, autor, cronológica por ano e por número de tombo oficial.
- [x] **Remoção de Livros:** Exclusão segura de registros com confirmação prévia.
- [x] **Separação por Estantes A-Z:** Mapeamento físico oficial com Estantes A-1, A-2 e A-3.
- [x] **Sistema de Notificações de Atraso:** Identificação de prazos vencidos, cálculo de dias em atraso e geração de mensagens formatadas para WhatsApp e E-mail.
- [x] **Gestão de Assistentes (Ada Melo & Xênia Cardoso):** Adição, seleção e exclusão de assistentes de mediação escolar.
- [x] **Cadastro de Usuários Subclassificados:** Professores, professoras, alunos, alunas (com série, turma e turno), servidores e servidoras.
- [x] **Exportação de Relatórios Oficiais:**
  - [x] Relatório em PDF para impressão e salvamento com assinatura da bibliotecária Ada Melo e da coordenação.
  - [x] Planilha Excel / CSV com codificação UTF-8 BOM.
  - [x] Documento XML estruturado e válido.
- [x] **Identidade Visual:** Cores Laranja e Azul, tipografia Montserrat, ícones minimalistas e componentes [Confirmar, Voltar, Cancelar, Corrigir].
