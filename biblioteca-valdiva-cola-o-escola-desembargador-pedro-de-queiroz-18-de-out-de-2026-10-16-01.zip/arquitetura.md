# Arquitetura do Sistema - Biblioteca Valdiva Colaço
**EMEF Desembargador Pedro de Queiroz**  
**Projeto:** Xênia Cardoso | **Ano:** 2026  
**Assistente:** Ada Melo  

---

## 1. Visão Arquitetural
A arquitetura do projeto foi desenhada para atender simultaneamente a dois pilares fundamentais:
1. **Núcleo Didático em Python (Etapas 1 a 6):** Aplicação CLI modular e limpa, ideal para portfólio acadêmico e aulas de programação.
2. **Interface Gráfica e Sistema de Produção:** Aplicação web responsiva com paleta Laranja & Azul, tipografia Montserrat, exportador para PDF e integração com banco de dados estruturado.

---

## 2. Modelo Relacional de Dados (PostgreSQL / SQL Schema)

```sql
-- Tabela de Assistentes Escolares
CREATE TABLE assistentes (
    id VARCHAR(36) PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    cargo VARCHAR(100) NOT NULL,
    especialidade VARCHAR(150),
    descricao TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao DATE NOT NULL DEFAULT CURRENT_DATE
);

-- Tabela do Acervo de Livros (Cadastro Oficial de Livros)
CREATE TABLE livros (
    id VARCHAR(36) PRIMARY KEY,
    tombo VARCHAR(20) UNIQUE NOT NULL,      -- Ex: '0001', '0002', '0166'
    titulo VARCHAR(255) NOT NULL,
    autor VARCHAR(255) NOT NULL,
    ano INT NOT NULL,
    disponivel VARCHAR(3) NOT NULL CHECK (disponivel IN ('Sim', 'Não')),
    genero VARCHAR(100) NOT NULL,
    estante VARCHAR(100) NOT NULL,         -- Ex: 'Estante A-1 · Infantojuvenil e Narrativas'
    estante_letra VARCHAR(10) NOT NULL,    -- Ex: 'A-1', 'A-2', 'A-3'
    secao VARCHAR(50),
    isbn VARCHAR(30),
    editora VARCHAR(100),
    sinopse TEXT,
    paginas INT,
    data_cadastro DATE NOT NULL DEFAULT CURRENT_DATE
);

-- Tabela de Leitores da Escola
CREATE TABLE usuarios (
    id VARCHAR(36) PRIMARY KEY,
    matricula VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(200) NOT NULL,
    categoria VARCHAR(20) NOT NULL CHECK (categoria IN ('aluno', 'aluna', 'professor', 'professora', 'servidor', 'servidora')),
    serie VARCHAR(50),                     -- Ex: '8º Ano EF', '9º Ano EF'
    turma VARCHAR(20),                     -- Ex: 'A', 'B', 'C', 'Integral'
    turno VARCHAR(30),                     -- Ex: 'Matutino', 'Vespertino', 'Noturno', 'Integral'
    telefone VARCHAR(30),
    email VARCHAR(150),
    data_cadastro DATE NOT NULL DEFAULT CURRENT_DATE
);

-- Tabela de Circulação (Empréstimos e Devoluções)
CREATE TABLE emprestimos (
    id VARCHAR(36) PRIMARY KEY,
    livro_id VARCHAR(36) REFERENCES livros(id) ON DELETE RESTRICT,
    usuario_id VARCHAR(36) REFERENCES usuarios(id) ON DELETE RESTRICT,
    data_emprestimo DATE NOT NULL,
    data_prevista DATE NOT NULL,
    data_devolucao DATE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('ativo', 'devolvido', 'atrasado')),
    observacoes TEXT,
    notificacao_enviada BOOLEAN DEFAULT FALSE,
    data_ultima_notificacao DATE
);
```

---

## 3. Estrutura Modular em Python (`biblioteca_valdiva_colaco.py`)
- **Etapa 1:** Menu principal interativo e controle de fluxo com funções estruturadas usando `pass`.
- **Etapa 2:** Representação dos dados do acervo em dicionários e listas globais com dados do acervo oficial.
- **Etapa 3:** Listagens e buscas por filtros utilizando *list comprehensions*.
- **Etapa 4:** Alteração de disponibilidade (`"Sim"` para `"Não"` e vice-versa).
- **Etapa 5:** Persistência de dados com `json.dump` e `json.load`.
- **Etapa 6:** Contadores estatísticos, ordenação com `sorted()` e `lambda`, sistema de alertas e exportação XML com `xml.etree.ElementTree`.

---

## 4. Estrutura de Interoperabilidade de Dados
1. **JSON Válido:** Exportação e importação integral da base no formato `application/json`.
2. **XML Válido e Estruturado:** Exportação no padrão `application/xml` com nós hierárquicos:
   `<biblioteca><metadados>...</metadados><acervo><livro>...</livro></acervo></biblioteca>`.
3. **CSV / Excel:** Compatível com Microsoft Excel e LibreOffice com codificação `UTF-8 BOM` (`\uFEFF`) e delimitador `;`.
